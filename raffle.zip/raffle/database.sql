CREATE DATABASE IF NOT EXISTS raffle_db;
USE raffle_db;

CREATE TABLE IF NOT EXISTS registration (
    idNum VARCHAR(30) PRIMARY KEY,
    campus VARCHAR(30) NOT NULL,
    studFName VARCHAR(100) NOT NULL,
    studLName VARCHAR(100) NOT NULL,
    amountPaid DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    attended ENUM('Yes', 'No') NOT NULL DEFAULT 'No'
);
