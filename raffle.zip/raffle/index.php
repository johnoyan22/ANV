<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Raffle System - Menu</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body class="w3-light-grey">
    <div class="w3-container w3-padding-32">
        <div class="w3-card w3-white w3-padding w3-round-large" style="max-width: 700px; margin: auto;">
            <h2 class="w3-center">Raffle Management System</h2>
            <p class="w3-center">Simple menu for all modules</p>
            <div class="w3-bar-block">
                <a href="registration.php" class="w3-button w3-blue w3-margin-bottom">Registration Module</a>
                <a href="attendance.php" class="w3-button w3-green w3-margin-bottom">Attendance Module</a>
                <a href="raffle.php" class="w3-button w3-purple w3-margin-bottom">Raffle Module</a>
                <a href="report_by_campus.php" class="w3-button w3-teal w3-margin-bottom">Report by Campus Module</a>
                <a href="summary_report.php" class="w3-button w3-orange">Summary Report Module</a>
            </div>
        </div>
    </div>
</body>
</html>
