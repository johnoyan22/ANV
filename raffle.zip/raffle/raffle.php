<?php
include "db.php";

$campuses = ["UC-Main", "LLM", "Banilad"];
$selectedCampus = "";
$message = "";
$winner = null;
$messageClass = "w3-blue";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selectedCampus = trim($_POST["campus"]);

    if (!in_array($selectedCampus, $campuses)) {
        $message = "Please select a valid campus.";
        $messageClass = "w3-red";
    } else {
        $campusEsc = mysqli_real_escape_string($conn, $selectedCampus);
        $sql = "SELECT idNum, campus, studFName, studLName
                FROM registration
                WHERE campus='$campusEsc' AND attended='Yes'";
        $result = mysqli_query($conn, $sql);

        $attendees = [];
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $attendees[] = $row;
            }
        }

        if (count($attendees) == 0) {
            $message = "No attendees found for selected campus.";
            $messageClass = "w3-orange";
        } else {
            $randomIndex = array_rand($attendees);
            $winner = $attendees[$randomIndex];
            $message = "CONGRATULATIONS!!!";
            $messageClass = "w3-green";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Raffle Module</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body class="w3-light-grey">
    <div class="w3-container w3-padding-24">
        <div class="w3-card w3-white w3-padding w3-round-large" style="max-width: 700px; margin: auto;">
            <h2>Raffle Module</h2>
            <p>Filter students by campus and reveal one lucky winner from attendees.</p>

            <form method="post" class="w3-margin-bottom">
                <p>
                    <label>Campus</label>
                    <select class="w3-select w3-border" name="campus" required>
                        <option value="" disabled <?php echo ($selectedCampus == "") ? "selected" : ""; ?>>Choose campus</option>
                        <?php foreach ($campuses as $c): ?>
                            <option value="<?php echo htmlspecialchars($c); ?>" <?php echo ($selectedCampus == $c) ? "selected" : ""; ?>>
                                <?php echo htmlspecialchars($c); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p>
                    <button class="w3-button w3-purple" type="submit">Reveal the Lucky Winner</button>
                    <a href="index.php" class="w3-button w3-gray">Back to Menu</a>
                </p>
            </form>

            <?php if ($message != ""): ?>
                <div class="w3-panel <?php echo $messageClass; ?> w3-padding">
                    <strong><?php echo htmlspecialchars($message); ?></strong>
                </div>
            <?php endif; ?>

            <?php if ($winner): ?>
                <div class="w3-panel w3-pale-green w3-border w3-round">
                    <h4>Lucky Winner</h4>
                    <p><strong>ID #:</strong> <?php echo htmlspecialchars($winner["idNum"]); ?></p>
                    <p><strong>Name:</strong> <?php echo htmlspecialchars($winner["studLName"] . ", " . $winner["studFName"]); ?></p>
                    <p><strong>Campus:</strong> <?php echo htmlspecialchars($winner["campus"]); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
