<?php
include "db.php";

$campuses = ["UC-Main", "Banilad", "LLM"];
$summaryRows = [];

foreach ($campuses as $campus) {
    $campusEsc = mysqli_real_escape_string($conn, $campus);
    $sql = "SELECT
                COUNT(*) AS registeredCount,
                SUM(CASE WHEN attended='Yes' THEN 1 ELSE 0 END) AS attendedCount,
                SUM(amountPaid) AS totalCollection
            FROM registration
            WHERE campus='$campusEsc'";
    $res = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($res);

    $summaryRows[] = [
        "campus" => $campus,
        "registered" => (int) ($data["registeredCount"] ?? 0),
        "attended" => (int) ($data["attendedCount"] ?? 0),
        "collection" => (float) ($data["totalCollection"] ?? 0)
    ];
}

$dateGenerated = date("Y-m-d h:i:s A");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Summary Report Module</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body class="w3-light-grey">
    <div class="w3-container w3-padding-24">
        <div class="w3-card w3-white w3-padding w3-round-large">
            <h2>Summary Report Module</h2>
            <p><strong>Date Generated:</strong> <?php echo htmlspecialchars($dateGenerated); ?></p>

            <div class="w3-responsive">
                <table class="w3-table-all">
                    <tr>
                        <th>Campus</th>
                        <th>Registered</th>
                        <th>Attended</th>
                        <th>Total Collection</th>
                    </tr>
                    <?php foreach ($summaryRows as $row): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row["campus"]); ?></td>
                            <td><?php echo $row["registered"]; ?></td>
                            <td><?php echo $row["attended"]; ?></td>
                            <td><?php echo number_format($row["collection"], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>

            <p class="w3-margin-top">
                <a href="index.php" class="w3-button w3-gray">Back to Menu</a>
            </p>
        </div>
    </div>
</body>
</html>
