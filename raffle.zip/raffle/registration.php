<?php
include "db.php";

$campuses = ["UC-Main", "LLM", "Banilad"];
$message = "";
$messageClass = "w3-blue";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add_student"])) {
    $idNum = trim($_POST["idNum"]);
    $campus = trim($_POST["campus"]);
    $studFName = trim($_POST["studFName"]);
    $studLName = trim($_POST["studLName"]);
    $amountPaid = trim($_POST["amountPaid"]);

    if ($idNum == "" || $campus == "" || $studFName == "" || $studLName == "" || $amountPaid == "") {
        $message = "Please fill in all fields.";
        $messageClass = "w3-red";
    } elseif (!in_array($campus, $campuses)) {
        $message = "Invalid campus selected.";
        $messageClass = "w3-red";
    } elseif (!is_numeric($amountPaid) || $amountPaid < 0) {
        $message = "Amount Paid must be a valid non-negative number.";
        $messageClass = "w3-red";
    } else {
        $idNumEsc = mysqli_real_escape_string($conn, $idNum);
        $campusEsc = mysqli_real_escape_string($conn, $campus);
        $fNameEsc = mysqli_real_escape_string($conn, $studFName);
        $lNameEsc = mysqli_real_escape_string($conn, $studLName);
        $amountEsc = mysqli_real_escape_string($conn, $amountPaid);

        $checkSql = "SELECT idNum FROM registration WHERE idNum='$idNumEsc'";
        $checkRes = mysqli_query($conn, $checkSql);

        if ($checkRes && mysqli_num_rows($checkRes) > 0) {
            $message = "ID already exists. Please use a different ID.";
            $messageClass = "w3-red";
        } else {
            $insertSql = "INSERT INTO registration (idNum, campus, studFName, studLName, amountPaid, attended)
                          VALUES ('$idNumEsc', '$campusEsc', '$fNameEsc', '$lNameEsc', '$amountEsc', 'No')";
            if (mysqli_query($conn, $insertSql)) {
                $message = "Student successfully registered.";
                $messageClass = "w3-green";
            } else {
                $message = "Error: " . mysqli_error($conn);
                $messageClass = "w3-red";
            }
        }
    }
}

if (isset($_GET["delete"])) {
    $deleteId = mysqli_real_escape_string($conn, $_GET["delete"]);
    $deleteSql = "DELETE FROM registration WHERE idNum='$deleteId'";
    if (mysqli_query($conn, $deleteSql)) {
        $message = "Student deleted successfully.";
        $messageClass = "w3-green";
    } else {
        $message = "Unable to delete student.";
        $messageClass = "w3-red";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["edit_student"])) {
    $editIdOriginal = trim($_POST["edit_id_original"]);
    $editCampus = trim($_POST["edit_campus"]);
    $editFName = trim($_POST["edit_studFName"]);
    $editLName = trim($_POST["edit_studLName"]);
    $editAmount = trim($_POST["edit_amountPaid"]);

    if ($editIdOriginal == "" || $editCampus == "" || $editFName == "" || $editLName == "" || $editAmount == "") {
        $message = "All edit fields are required.";
        $messageClass = "w3-red";
    } elseif (!in_array($editCampus, $campuses)) {
        $message = "Invalid campus selected in edit form.";
        $messageClass = "w3-red";
    } elseif (!is_numeric($editAmount) || $editAmount < 0) {
        $message = "Amount Paid in edit form must be a valid non-negative number.";
        $messageClass = "w3-red";
    } else {
        $idEsc = mysqli_real_escape_string($conn, $editIdOriginal);
        $campusEsc = mysqli_real_escape_string($conn, $editCampus);
        $fNameEsc = mysqli_real_escape_string($conn, $editFName);
        $lNameEsc = mysqli_real_escape_string($conn, $editLName);
        $amountEsc = mysqli_real_escape_string($conn, $editAmount);

        $updateSql = "UPDATE registration
                      SET campus='$campusEsc', studFName='$fNameEsc', studLName='$lNameEsc', amountPaid='$amountEsc'
                      WHERE idNum='$idEsc'";
        if (mysqli_query($conn, $updateSql)) {
            $message = "Student record updated successfully.";
            $messageClass = "w3-green";
        } else {
            $message = "Update failed: " . mysqli_error($conn);
            $messageClass = "w3-red";
        }
    }
}

$studentsSql = "SELECT * FROM registration ORDER BY studLName ASC, studFName ASC";
$studentsRes = mysqli_query($conn, $studentsSql);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration Module</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body class="w3-light-grey">
    <div class="w3-container w3-padding-24">
        <div class="w3-card w3-white w3-padding w3-round-large">
            <h2>Registration Module</h2>

            <?php if ($message != ""): ?>
                <div class="w3-panel <?php echo $messageClass; ?> w3-padding">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="post" class="w3-container w3-padding-16 w3-border w3-round">
                <p><strong>Add/Register Student</strong></p>
                <p>
                    <label>ID #</label>
                    <input class="w3-input w3-border" type="text" name="idNum" required>
                </p>
                <p>
                    <label>Campus</label>
                    <select class="w3-select w3-border" name="campus" required>
                        <option value="" disabled selected>Choose campus</option>
                        <?php foreach ($campuses as $c): ?>
                            <option value="<?php echo htmlspecialchars($c); ?>"><?php echo htmlspecialchars($c); ?></option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p>
                    <label>Student First Name</label>
                    <input class="w3-input w3-border" type="text" name="studFName" required>
                </p>
                <p>
                    <label>Student Last Name</label>
                    <input class="w3-input w3-border" type="text" name="studLName" required>
                </p>
                <p>
                    <label>Amount Paid</label>
                    <input class="w3-input w3-border" type="number" step="0.01" min="0" name="amountPaid" required>
                </p>
                <p>
                    <button class="w3-button w3-blue" type="submit" name="add_student">Register Student</button>
                    <a href="index.php" class="w3-button w3-gray">Back to Menu</a>
                </p>
            </form>

            <div class="w3-responsive w3-margin-top">
                <table class="w3-table-all w3-small">
                    <tr>
                        <th>ID #</th>
                        <th>Name</th>
                        <th>Campus</th>
                        <th>Amount Paid</th>
                        <th>Actions</th>
                    </tr>
                    <?php if ($studentsRes && mysqli_num_rows($studentsRes) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($studentsRes)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row["idNum"]); ?></td>
                                <td><?php echo htmlspecialchars($row["studLName"] . ", " . $row["studFName"]); ?></td>
                                <td><?php echo htmlspecialchars($row["campus"]); ?></td>
                                <td><?php echo number_format((float)$row["amountPaid"], 2); ?></td>
                                <td>
                                    <button class="w3-button w3-green w3-small"
                                            onclick="showEditForm('<?php echo htmlspecialchars($row["idNum"], ENT_QUOTES); ?>',
                                                                  '<?php echo htmlspecialchars($row["campus"], ENT_QUOTES); ?>',
                                                                  '<?php echo htmlspecialchars($row["studFName"], ENT_QUOTES); ?>',
                                                                  '<?php echo htmlspecialchars($row["studLName"], ENT_QUOTES); ?>',
                                                                  '<?php echo htmlspecialchars($row["amountPaid"], ENT_QUOTES); ?>')">
                                        Edit
                                    </button>
                                    <a class="w3-button w3-red w3-small"
                                       href="registration.php?delete=<?php echo urlencode($row["idNum"]); ?>"
                                       onclick="return confirm('Delete this student?');">
                                        Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="w3-center">No registered students yet.</td>
                        </tr>
                    <?php endif; ?>
                </table>
            </div>

            <div id="editCard" class="w3-container w3-padding-16 w3-border w3-round w3-margin-top" style="display:none;">
                <p><strong>Edit Student</strong></p>
                <form method="post">
                    <input type="hidden" name="edit_id_original" id="edit_id_original">
                    <p>
                        <label>ID #</label>
                        <input class="w3-input w3-border" type="text" id="edit_id_display" disabled>
                    </p>
                    <p>
                        <label>Campus</label>
                        <select class="w3-select w3-border" name="edit_campus" id="edit_campus" required>
                            <?php foreach ($campuses as $c): ?>
                                <option value="<?php echo htmlspecialchars($c); ?>"><?php echo htmlspecialchars($c); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </p>
                    <p>
                        <label>First Name</label>
                        <input class="w3-input w3-border" type="text" name="edit_studFName" id="edit_studFName" required>
                    </p>
                    <p>
                        <label>Last Name</label>
                        <input class="w3-input w3-border" type="text" name="edit_studLName" id="edit_studLName" required>
                    </p>
                    <p>
                        <label>Amount Paid</label>
                        <input class="w3-input w3-border" type="number" step="0.01" min="0" name="edit_amountPaid" id="edit_amountPaid" required>
                    </p>
                    <p>
                        <button class="w3-button w3-green" type="submit" name="edit_student">Save Changes</button>
                        <button class="w3-button w3-gray" type="button" onclick="hideEditForm()">Cancel</button>
                    </p>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showEditForm(idNum, campus, fName, lName, amountPaid) {
            document.getElementById("editCard").style.display = "block";
            document.getElementById("edit_id_original").value = idNum;
            document.getElementById("edit_id_display").value = idNum;
            document.getElementById("edit_campus").value = campus;
            document.getElementById("edit_studFName").value = fName;
            document.getElementById("edit_studLName").value = lName;
            document.getElementById("edit_amountPaid").value = amountPaid;
            window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
        }

        function hideEditForm() {
            document.getElementById("editCard").style.display = "none";
        }
    </script>
</body>
</html>
