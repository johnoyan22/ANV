<?php
include "db.php";

$campuses = ["UC-Main", "Banilad", "LLM"];
$selectedCampus = "";
$students = [];
$registeredCount = 0;
$attendedCount = 0;
$message = "";
$messageClass = "w3-blue";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selectedCampus = trim($_POST["campus"]);

    if (!in_array($selectedCampus, $campuses)) {
        $message = "Please select a valid campus.";
        $messageClass = "w3-red";
    } else {
        $campusEsc = mysqli_real_escape_string($conn, $selectedCampus);

        $studentSql = "SELECT idNum, studFName, studLName, amountPaid, attended
                       FROM registration
                       WHERE campus='$campusEsc'
                       ORDER BY studLName ASC, studFName ASC";
        $studentRes = mysqli_query($conn, $studentSql);
        if ($studentRes) {
            while ($row = mysqli_fetch_assoc($studentRes)) {
                $students[] = $row;
            }
        }

        $countRegSql = "SELECT COUNT(*) AS totalReg FROM registration WHERE campus='$campusEsc'";
        $countRegRes = mysqli_query($conn, $countRegSql);
        if ($countRegRes) {
            $registeredCount = (int) mysqli_fetch_assoc($countRegRes)["totalReg"];
        }

        $countAttSql = "SELECT COUNT(*) AS totalAtt FROM registration WHERE campus='$campusEsc' AND attended='Yes'";
        $countAttRes = mysqli_query($conn, $countAttSql);
        if ($countAttRes) {
            $attendedCount = (int) mysqli_fetch_assoc($countAttRes)["totalAtt"];
        }

        $message = "Report generated.";
        $messageClass = "w3-green";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Report by Campus Module</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body class="w3-light-grey">
    <div class="w3-container w3-padding-24">
        <div class="w3-card w3-white w3-padding w3-round-large">
            <h2>Report by Campus Module</h2>

            <form method="post">
                <p>
                    <label>Campus</label>
                    <select class="w3-select w3-border" name="campus" required>
                        <option value="" disabled <?php echo ($selectedCampus == "") ? "selected" : ""; ?>>Choose campus</option>
                        <?php foreach ($campuses as $c): ?>
                            <option value="<?php echo htmlspecialchars($c); ?>" <?php echo ($selectedCampus == $c) ? "selected" : ""; ?>>
                                <?php echo htmlspecialchars($c); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p>
                    <button class="w3-button w3-teal" type="submit">Generate Report</button>
                    <a href="index.php" class="w3-button w3-gray">Back to Menu</a>
                </p>
            </form>

            <?php if ($message != ""): ?>
                <div class="w3-panel <?php echo $messageClass; ?> w3-padding">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <?php if ($selectedCampus != "" && in_array($selectedCampus, $campuses)): ?>
                <h4>Campus: <?php echo htmlspecialchars($selectedCampus); ?></h4>
                <div class="w3-responsive">
                    <table class="w3-table-all w3-small">
                        <tr>
                            <th>ID #</th>
                            <th>Name</th>
                            <th>Amount Paid</th>
                            <th>Attended</th>
                        </tr>
                        <?php if (count($students) > 0): ?>
                            <?php foreach ($students as $row): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row["idNum"]); ?></td>
                                    <td><?php echo htmlspecialchars($row["studLName"] . ", " . $row["studFName"]); ?></td>
                                    <td><?php echo number_format((float) $row["amountPaid"], 2); ?></td>
                                    <td><?php echo htmlspecialchars($row["attended"]); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="w3-center">No registered students for this campus.</td>
                            </tr>
                        <?php endif; ?>
                    </table>
                </div>
                <div class="w3-panel w3-pale-blue w3-border w3-margin-top">
                    <p><strong>Total Registered:</strong> <?php echo $registeredCount; ?></p>
                    <p><strong>Total Attendees:</strong> <?php echo $attendedCount; ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
