<?php
include "db.php";

$message = "";
$messageClass = "w3-blue";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idNum = trim($_POST["idNum"]);

    if ($idNum == "") {
        $message = "Please enter a student ID.";
        $messageClass = "w3-red";
    } else {
        $idEsc = mysqli_real_escape_string($conn, $idNum);
        $sql = "SELECT idNum, attended FROM registration WHERE idNum='$idEsc'";
        $result = mysqli_query($conn, $sql);

        if (!$result || mysqli_num_rows($result) == 0) {
            $message = "ID NOT YET REGISTERED.";
            $messageClass = "w3-red";
        } else {
            $row = mysqli_fetch_assoc($result);
            if ($row["attended"] == "Yes") {
                $message = "Attendance RECORD ALREADY EXISTS.";
                $messageClass = "w3-orange";
            } else {
                $updateSql = "UPDATE registration SET attended='Yes' WHERE idNum='$idEsc'";
                if (mysqli_query($conn, $updateSql)) {
                    $message = "Attendance SUCCESSFULLY RECORDED.";
                    $messageClass = "w3-green";
                } else {
                    $message = "Could not record attendance.";
                    $messageClass = "w3-red";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Attendance Module</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body class="w3-light-grey">
    <div class="w3-container w3-padding-24">
        <div class="w3-card w3-white w3-padding w3-round-large" style="max-width: 650px; margin: auto;">
            <h2>Attendance Module</h2>
            <p>Enter Student ID to mark attendance.</p>

            <?php if ($message != ""): ?>
                <div class="w3-panel <?php echo $messageClass; ?> w3-padding">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="post">
                <p>
                    <label>Student ID #</label>
                    <input class="w3-input w3-border" type="text" name="idNum" required>
                </p>
                <p>
                    <button class="w3-button w3-green" type="submit">Record Attendance</button>
                    <a href="index.php" class="w3-button w3-gray">Back to Menu</a>
                </p>
            </form>
        </div>
    </div>
</body>
</html>
