-- Veterinary Clinic Consultations System
-- Database Schema

CREATE DATABASE IF NOT EXISTS clinic;
USE clinic;

-- PetOwner Table
CREATE TABLE PetOwner (
    petOwnerID   VARCHAR(50)  PRIMARY KEY,
    petOwnerFName VARCHAR(100) NOT NULL,
    petOwnerLName VARCHAR(100) NOT NULL,
    petOwnerBDate DATE         NOT NULL,
    petOwnerTelNo VARCHAR(20)  NOT NULL,
    status        ENUM('active', 'deleted') DEFAULT 'active'
);

-- Veterinarian Table
CREATE TABLE Veterinarian (
    vetID       VARCHAR(50)  PRIMARY KEY,
    vetFName    VARCHAR(100) NOT NULL,
    vetLName    VARCHAR(100) NOT NULL,
    vetAddress  VARCHAR(255) NOT NULL,
    vetSpecial  VARCHAR(100) NOT NULL,
    status      ENUM('active', 'deleted') DEFAULT 'active'
);

-- Pet Table
CREATE TABLE Pet (
    petID       VARCHAR(50)  PRIMARY KEY,
    petName     VARCHAR(100) NOT NULL,
    petType     VARCHAR(50)  NOT NULL,
    petBreed    VARCHAR(100) NOT NULL,
    petBDate    DATE         NOT NULL,
    petOwnerID  VARCHAR(50)  NOT NULL,
    status      ENUM('active', 'deleted') DEFAULT 'active',
    FOREIGN KEY (petOwnerID) REFERENCES PetOwner(petOwnerID)
);

-- Consultation Table
CREATE TABLE Consultation (
    consultID    VARCHAR(50)  PRIMARY KEY,
    petID        VARCHAR(50)  NOT NULL,
    vetID        VARCHAR(50)  NOT NULL,
    consultDate  DATETIME     NOT NULL,
    diagnoses    TEXT         NOT NULL,
    prescription TEXT         NOT NULL,
    status       ENUM('active', 'deleted') DEFAULT 'active',
    FOREIGN KEY (petID) REFERENCES Pet(petID),
    FOREIGN KEY (vetID) REFERENCES Veterinarian(vetID)
);

-- Sample Data
INSERT INTO PetOwner VALUES
('PO001', 'Juan', 'Dela Cruz', '1990-05-15', '09171234567', 'active'),
('PO002', 'Maria', 'Santos', '1985-08-22', '09181234567', 'active'),
('PO003', 'Pedro', 'Reyes', '1992-03-10', '09191234567', 'active');

INSERT INTO Veterinarian VALUES
('VET001', 'Ana', 'Garcia', '123 Main St, Cebu City', 'General Practice', 'active'),
('VET002', 'Carlos', 'Lopez', '456 Oak Ave, Cebu City', 'Surgery', 'active'),
('VET003', 'Elena', 'Torres', '789 Pine Rd, Cebu City', 'Dermatology', 'active');

INSERT INTO Pet VALUES
('PET001', 'Buddy', 'Dog', 'Golden Retriever', '2020-01-10', 'PO001', 'active'),
('PET002', 'Whiskers', 'Cat', 'Persian', '2019-06-20', 'PO001', 'active'),
('PET003', 'Max', 'Dog', 'Labrador', '2021-03-15', 'PO002', 'active'),
('PET004', 'Luna', 'Cat', 'Siamese', '2020-11-05', 'PO003', 'active');

INSERT INTO Consultation VALUES
('CON001', 'PET001', 'VET001', '2025-01-15 10:00:00', 'Mild skin irritation', 'Apply topical cream twice daily', 'active'),
('CON002', 'PET002', 'VET003', '2025-02-20 14:30:00', 'Flea infestation', 'Flea treatment shampoo and oral medication', 'active'),
('CON003', 'PET003', 'VET002', '2025-03-05 09:00:00', 'Fractured leg', 'Surgery required, pain medication prescribed', 'active'),
('CON004', 'PET001', 'VET001', '2025-04-10 11:00:00', 'Annual checkup - healthy', 'Vitamins supplement', 'active'),
('CON005', 'PET004', 'VET003', '2025-05-18 16:00:00', 'Allergic reaction', 'Antihistamine prescribed', 'active');
