<?php
include "conn.php";

$count = "";
$label = "";

// Filter by specialization
if (isset($_GET['btn_special'])) {
    $special = $_GET['specialization'];
    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM Veterinarian WHERE vetSpecial='$special' AND status='active'");
    $row = mysqli_fetch_assoc($result);
    $count = $row['total'];
    $label = "Veterinarians with specialization: $special";
}

// Filter by Pet ID
if (isset($_GET['btn_pet'])) {
    $petID = $_GET['petID'];
    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM Consultation WHERE petID='$petID' AND status='active'");
    $row = mysqli_fetch_assoc($result);
    $count = $row['total'];
    $label = "Consultations for Pet ID: $petID";
}

// Filter by Pet Owner ID
if (isset($_GET['btn_owner'])) {
    $ownerID = $_GET['petOwnerID'];
    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM Consultation c JOIN Pet p ON c.petID=p.petID WHERE p.petOwnerID='$ownerID' AND c.status='active'");
    $row = mysqli_fetch_assoc($result);
    $count = $row['total'];
    $label = "Consultations for Pet Owner ID: $ownerID";
}

// Filter by Veterinarian ID
if (isset($_GET['btn_vet'])) {
    $vetID = $_GET['vetID'];
    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM Consultation WHERE vetID='$vetID' AND status='active'");
    $row = mysqli_fetch_assoc($result);
    $count = $row['total'];
    $label = "Consultations for Veterinarian ID: $vetID";
}

// Filter by date range
if (isset($_GET['btn_date'])) {
    $from = $_GET['date_from'];
    $to = $_GET['date_to'];
    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM Consultation WHERE consultDate BETWEEN '$from 00:00:00' AND '$to 23:59:59' AND status='active'");
    $row = mysqli_fetch_assoc($result);
    $count = $row['total'];
    $label = "Consultations from $from to $to";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Inquiry</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Consultations Inquiry</h2>
    <a href="index.php">Back to Menu</a> | <a href="logout.php">Logout</a>
    <hr>

    <h3>1. Filter Veterinarians by Specialization</h3>
    <form method="GET">
        <select name="specialization">
            <option value="General Practice">General Practice</option>
            <option value="Surgery">Surgery</option>
            <option value="Dermatology">Dermatology</option>
        </select>
        <input type="submit" name="btn_special" value="Search">
    </form>
    <hr>

    <h3>2. Filter Consultations by Pet ID</h3>
    <form method="GET">
        Pet ID: <input type="text" name="petID" placeholder="PET001">
        <input type="submit" name="btn_pet" value="Search">
    </form>
    <hr>

    <h3>3. Filter Consultations by Pet Owner ID</h3>
    <form method="GET">
        Owner ID: <input type="text" name="petOwnerID" placeholder="PO001">
        <input type="submit" name="btn_owner" value="Search">
    </form>
    <hr>

    <h3>4. Filter Consultations by Veterinarian ID</h3>
    <form method="GET">
        Vet ID: <input type="text" name="vetID" placeholder="VET001">
        <input type="submit" name="btn_vet" value="Search">
    </form>
    <hr>

    <h3>5. Filter Consultations by Date Range</h3>
    <form method="GET">
        From: <input type="date" name="date_from">
        To: <input type="date" name="date_to">
        <input type="submit" name="btn_date" value="Search">
    </form>
    <hr>

    <?php if ($count !== "") { ?>
    <h3>Result</h3>
    <p><?php echo $label; ?></p>
    <p><b>COUNT: <?php echo $count; ?></b></p>
    <?php } ?>
</body>
</html>
