<?php
include "conn.php";

// ADD
if (isset($_POST['add'])) {
    $id = $_POST['petOwnerID'];
    $fname = $_POST['petOwnerFName'];
    $lname = $_POST['petOwnerLName'];
    $bdate = $_POST['petOwnerBDate'];
    $tel = $_POST['petOwnerTelNo'];
    mysqli_query($conn, "INSERT INTO PetOwner VALUES ('$id','$fname','$lname','$bdate','$tel','active')");
    header("Location: pet_owners.php");
    exit;
}

// UPDATE
if (isset($_POST['update'])) {
    $id = $_POST['petOwnerID'];
    $fname = $_POST['petOwnerFName'];
    $lname = $_POST['petOwnerLName'];
    $bdate = $_POST['petOwnerBDate'];
    $tel = $_POST['petOwnerTelNo'];
    mysqli_query($conn, "UPDATE PetOwner SET petOwnerFName='$fname', petOwnerLName='$lname', petOwnerBDate='$bdate', petOwnerTelNo='$tel' WHERE petOwnerID='$id'");
    header("Location: pet_owners.php");
    exit;
}

// DELETE (logical)
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "UPDATE PetOwner SET status='deleted' WHERE petOwnerID='$id'");
    header("Location: pet_owners.php");
    exit;
}

// SEARCH
$search = "";
$where = "WHERE status='active'";
if (isset($_GET['search']) && $_GET['search'] != "") {
    $search = $_GET['search'];
    $where = "WHERE status='active' AND (petOwnerID LIKE '%$search%' OR petOwnerFName LIKE '%$search%' OR petOwnerLName LIKE '%$search%' OR petOwnerTelNo LIKE '%$search%')";
}

$result = mysqli_query($conn, "SELECT * FROM PetOwner $where ORDER BY petOwnerID");

// EDIT mode
$edit = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $editResult = mysqli_query($conn, "SELECT * FROM PetOwner WHERE petOwnerID='$id' AND status='active'");
    $edit = mysqli_fetch_assoc($editResult);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Pet Owners</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Pet Owner Management</h2>
    <a href="index.php">Back to Menu</a> | <a href="logout.php">Logout</a>
    <hr>

    <h3><?php echo $edit ? "Update Pet Owner" : "Add Pet Owner"; ?></h3>
    <form method="POST">
        <?php if ($edit) { ?>
            <input type="hidden" name="petOwnerID" value="<?php echo $edit['petOwnerID']; ?>">
            ID: <?php echo $edit['petOwnerID']; ?><br>
        <?php } else { ?>
            ID: <input type="text" name="petOwnerID" required><br>
        <?php } ?>
        First Name: <input type="text" name="petOwnerFName" value="<?php echo $edit ? $edit['petOwnerFName'] : ''; ?>" required><br>
        Last Name: <input type="text" name="petOwnerLName" value="<?php echo $edit ? $edit['petOwnerLName'] : ''; ?>" required><br>
        Birth Date: <input type="date" name="petOwnerBDate" value="<?php echo $edit ? $edit['petOwnerBDate'] : ''; ?>" required><br>
        Telephone: <input type="text" name="petOwnerTelNo" value="<?php echo $edit ? $edit['petOwnerTelNo'] : ''; ?>" required><br>
        <?php if ($edit) { ?>
            <input type="submit" name="update" value="Update">
            <a href="pet_owners.php">Cancel</a>
        <?php } else { ?>
            <input type="submit" name="add" value="Add">
        <?php } ?>
    </form>
    <hr>

    <form method="GET">
        Search: <input type="text" name="search" value="<?php echo $search; ?>">
        <input type="submit" value="Search">
        <a href="pet_owners.php">Show All</a>
    </form>
    <br>

    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th><th>First Name</th><th>Last Name</th><th>Birth Date</th><th>Telephone</th><th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo $row['petOwnerID']; ?></td>
            <td><?php echo $row['petOwnerFName']; ?></td>
            <td><?php echo $row['petOwnerLName']; ?></td>
            <td><?php echo $row['petOwnerBDate']; ?></td>
            <td><?php echo $row['petOwnerTelNo']; ?></td>
            <td>
                <a href="pet_owners.php?edit=<?php echo $row['petOwnerID']; ?>">Edit</a> |
                <a href="pet_owners.php?delete=<?php echo $row['petOwnerID']; ?>" onclick="return confirm('Delete?')">Delete</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
