<?php
include "conn.php";

// ADD
if (isset($_POST['add'])) {
    $id = $_POST['petID'];
    $name = $_POST['petName'];
    $type = $_POST['petType'];
    $breed = $_POST['petBreed'];
    $bdate = $_POST['petBDate'];
    $owner = $_POST['petOwnerID'];
    mysqli_query($conn, "INSERT INTO Pet VALUES ('$id','$name','$type','$breed','$bdate','$owner','active')");
    header("Location: pets.php");
    exit;
}

// UPDATE
if (isset($_POST['update'])) {
    $id = $_POST['petID'];
    $name = $_POST['petName'];
    $type = $_POST['petType'];
    $breed = $_POST['petBreed'];
    $bdate = $_POST['petBDate'];
    $owner = $_POST['petOwnerID'];
    mysqli_query($conn, "UPDATE Pet SET petName='$name', petType='$type', petBreed='$breed', petBDate='$bdate', petOwnerID='$owner' WHERE petID='$id'");
    header("Location: pets.php");
    exit;
}

// DELETE (logical)
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "UPDATE Pet SET status='deleted' WHERE petID='$id'");
    header("Location: pets.php");
    exit;
}

// Get owners for dropdown
$owners = mysqli_query($conn, "SELECT petOwnerID, petOwnerFName, petOwnerLName FROM PetOwner WHERE status='active'");

// SEARCH
$search = "";
$where = "WHERE p.status='active'";
if (isset($_GET['search']) && $_GET['search'] != "") {
    $search = $_GET['search'];
    $where = "WHERE p.status='active' AND (p.petID LIKE '%$search%' OR p.petName LIKE '%$search%' OR p.petType LIKE '%$search%')";
}

$result = mysqli_query($conn, "SELECT p.*, o.petOwnerFName, o.petOwnerLName FROM Pet p JOIN PetOwner o ON p.petOwnerID=o.petOwnerID $where ORDER BY p.petID");

// EDIT mode
$edit = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $editResult = mysqli_query($conn, "SELECT * FROM Pet WHERE petID='$id' AND status='active'");
    $edit = mysqli_fetch_assoc($editResult);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Pets</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Pet Management</h2>
    <a href="index.php">Back to Menu</a> | <a href="logout.php">Logout</a>
    <hr>

    <h3><?php echo $edit ? "Update Pet" : "Add Pet"; ?></h3>
    <form method="POST">
        <?php if ($edit) { ?>
            <input type="hidden" name="petID" value="<?php echo $edit['petID']; ?>">
            ID: <?php echo $edit['petID']; ?><br>
        <?php } else { ?>
            ID: <input type="text" name="petID" required><br>
        <?php } ?>
        Name: <input type="text" name="petName" value="<?php echo $edit ? $edit['petName'] : ''; ?>" required><br>
        Type: <input type="text" name="petType" value="<?php echo $edit ? $edit['petType'] : ''; ?>" required><br>
        Breed: <input type="text" name="petBreed" value="<?php echo $edit ? $edit['petBreed'] : ''; ?>" required><br>
        Birth Date: <input type="date" name="petBDate" value="<?php echo $edit ? $edit['petBDate'] : ''; ?>" required><br>
        Owner:
        <select name="petOwnerID" required>
            <?php
            mysqli_data_seek($owners, 0);
            while ($o = mysqli_fetch_assoc($owners)) {
                $selected = ($edit && $edit['petOwnerID'] == $o['petOwnerID']) ? "selected" : "";
                echo "<option value='{$o['petOwnerID']}' $selected>{$o['petOwnerID']} - {$o['petOwnerFName']} {$o['petOwnerLName']}</option>";
            }
            ?>
        </select><br>
        <?php if ($edit) { ?>
            <input type="submit" name="update" value="Update">
            <a href="pets.php">Cancel</a>
        <?php } else { ?>
            <input type="submit" name="add" value="Add">
        <?php } ?>
    </form>
    <hr>

    <form method="GET">
        Search: <input type="text" name="search" value="<?php echo $search; ?>">
        <input type="submit" value="Search">
        <a href="pets.php">Show All</a>
    </form>
    <br>

    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th><th>Name</th><th>Type</th><th>Breed</th><th>Birth Date</th><th>Owner</th><th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo $row['petID']; ?></td>
            <td><?php echo $row['petName']; ?></td>
            <td><?php echo $row['petType']; ?></td>
            <td><?php echo $row['petBreed']; ?></td>
            <td><?php echo $row['petBDate']; ?></td>
            <td><?php echo $row['petOwnerFName'] . " " . $row['petOwnerLName']; ?></td>
            <td>
                <a href="pets.php?edit=<?php echo $row['petID']; ?>">Edit</a> |
                <a href="pets.php?delete=<?php echo $row['petID']; ?>" onclick="return confirm('Delete?')">Delete</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
