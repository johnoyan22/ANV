<?php
include "conn.php";

// ADD
if (isset($_POST['add'])) {
    $id = $_POST['consultID'];
    $pet = $_POST['petID'];
    $vet = $_POST['vetID'];
    $date = $_POST['consultDate'];
    $diag = $_POST['diagnoses'];
    $pres = $_POST['prescription'];
    mysqli_query($conn, "INSERT INTO Consultation VALUES ('$id','$pet','$vet','$date','$diag','$pres','active')");
    header("Location: consultations.php");
    exit;
}

// UPDATE
if (isset($_POST['update'])) {
    $id = $_POST['consultID'];
    $pet = $_POST['petID'];
    $vet = $_POST['vetID'];
    $date = $_POST['consultDate'];
    $diag = $_POST['diagnoses'];
    $pres = $_POST['prescription'];
    mysqli_query($conn, "UPDATE Consultation SET petID='$pet', vetID='$vet', consultDate='$date', diagnoses='$diag', prescription='$pres' WHERE consultID='$id'");
    header("Location: consultations.php");
    exit;
}

// DELETE (logical)
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "UPDATE Consultation SET status='deleted' WHERE consultID='$id'");
    header("Location: consultations.php");
    exit;
}

$pets = mysqli_query($conn, "SELECT petID, petName FROM Pet WHERE status='active'");
$vets = mysqli_query($conn, "SELECT vetID, vetFName, vetLName FROM Veterinarian WHERE status='active'");

// SEARCH
$search = "";
$where = "WHERE c.status='active'";
if (isset($_GET['search']) && $_GET['search'] != "") {
    $search = $_GET['search'];
    $where = "WHERE c.status='active' AND (c.consultID LIKE '%$search%' OR p.petName LIKE '%$search%')";
}

$result = mysqli_query($conn, "SELECT c.*, p.petName, v.vetFName, v.vetLName FROM Consultation c JOIN Pet p ON c.petID=p.petID JOIN Veterinarian v ON c.vetID=v.vetID $where ORDER BY c.consultDate DESC");

// EDIT mode
$edit = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $editResult = mysqli_query($conn, "SELECT * FROM Consultation WHERE consultID='$id' AND status='active'");
    $edit = mysqli_fetch_assoc($editResult);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Consultations</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Consultations Management</h2>
    <a href="index.php">Back to Menu</a> | <a href="logout.php">Logout</a>
    <hr>

    <h3><?php echo $edit ? "Update Consultation" : "Add Consultation"; ?></h3>
    <form method="POST">
        <?php if ($edit) { ?>
            <input type="hidden" name="consultID" value="<?php echo $edit['consultID']; ?>">
            ID: <?php echo $edit['consultID']; ?><br>
        <?php } else { ?>
            ID: <input type="text" name="consultID" required><br>
        <?php } ?>
        Date: <input type="datetime-local" name="consultDate" value="<?php echo $edit ? str_replace(' ', 'T', substr($edit['consultDate'], 0, 16)) : ''; ?>" required><br>
        Pet:
        <select name="petID" required>
            <?php
            mysqli_data_seek($pets, 0);
            while ($p = mysqli_fetch_assoc($pets)) {
                $selected = ($edit && $edit['petID'] == $p['petID']) ? "selected" : "";
                echo "<option value='{$p['petID']}' $selected>{$p['petID']} - {$p['petName']}</option>";
            }
            ?>
        </select><br>
        Veterinarian:
        <select name="vetID" required>
            <?php
            mysqli_data_seek($vets, 0);
            while ($v = mysqli_fetch_assoc($vets)) {
                $selected = ($edit && $edit['vetID'] == $v['vetID']) ? "selected" : "";
                echo "<option value='{$v['vetID']}' $selected>{$v['vetID']} - {$v['vetFName']} {$v['vetLName']}</option>";
            }
            ?>
        </select><br>
        Diagnoses: <textarea name="diagnoses" required><?php echo $edit ? $edit['diagnoses'] : ''; ?></textarea><br>
        Prescription: <textarea name="prescription" required><?php echo $edit ? $edit['prescription'] : ''; ?></textarea><br>
        <?php if ($edit) { ?>
            <input type="submit" name="update" value="Update">
            <a href="consultations.php">Cancel</a>
        <?php } else { ?>
            <input type="submit" name="add" value="Add">
        <?php } ?>
    </form>
    <hr>

    <form method="GET">
        Search: <input type="text" name="search" value="<?php echo $search; ?>">
        <input type="submit" value="Search">
        <a href="consultations.php">Show All</a>
    </form>
    <br>

    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th><th>Date</th><th>Pet</th><th>Vet</th><th>Diagnoses</th><th>Prescription</th><th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo $row['consultID']; ?></td>
            <td><?php echo $row['consultDate']; ?></td>
            <td><?php echo $row['petName']; ?></td>
            <td><?php echo $row['vetFName'] . " " . $row['vetLName']; ?></td>
            <td><?php echo $row['diagnoses']; ?></td>
            <td><?php echo $row['prescription']; ?></td>
            <td>
                <a href="consultations.php?edit=<?php echo $row['consultID']; ?>">Edit</a> |
                <a href="consultations.php?delete=<?php echo $row['consultID']; ?>" onclick="return confirm('Delete?')">Delete</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
