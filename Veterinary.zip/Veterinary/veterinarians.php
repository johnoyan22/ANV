<?php
include "conn.php";

// ADD
if (isset($_POST['add'])) {
    $id = $_POST['vetID'];
    $fname = $_POST['vetFName'];
    $lname = $_POST['vetLName'];
    $address = $_POST['vetAddress'];
    $special = $_POST['vetSpecial'];
    mysqli_query($conn, "INSERT INTO Veterinarian VALUES ('$id','$fname','$lname','$address','$special','active')");
    header("Location: veterinarians.php");
    exit;
}

// UPDATE
if (isset($_POST['update'])) {
    $id = $_POST['vetID'];
    $fname = $_POST['vetFName'];
    $lname = $_POST['vetLName'];
    $address = $_POST['vetAddress'];
    $special = $_POST['vetSpecial'];
    mysqli_query($conn, "UPDATE Veterinarian SET vetFName='$fname', vetLName='$lname', vetAddress='$address', vetSpecial='$special' WHERE vetID='$id'");
    header("Location: veterinarians.php");
    exit;
}

// DELETE (logical)
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "UPDATE Veterinarian SET status='deleted' WHERE vetID='$id'");
    header("Location: veterinarians.php");
    exit;
}

// SEARCH
$search = "";
$where = "WHERE status='active'";
if (isset($_GET['search']) && $_GET['search'] != "") {
    $search = $_GET['search'];
    $where = "WHERE status='active' AND (vetID LIKE '%$search%' OR vetFName LIKE '%$search%' OR vetLName LIKE '%$search%' OR vetSpecial LIKE '%$search%')";
}

$result = mysqli_query($conn, "SELECT * FROM Veterinarian $where ORDER BY vetID");

// EDIT mode
$edit = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $editResult = mysqli_query($conn, "SELECT * FROM Veterinarian WHERE vetID='$id' AND status='active'");
    $edit = mysqli_fetch_assoc($editResult);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Veterinarians</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Veterinarian Management</h2>
    <a href="index.php">Back to Menu</a> | <a href="logout.php">Logout</a>
    <hr>

    <!-- ADD / EDIT FORM -->
    <h3><?php echo $edit ? "Update Veterinarian" : "Add Veterinarian"; ?></h3>
    <form method="POST">
        <?php if ($edit) { ?>
            <input type="hidden" name="vetID" value="<?php echo $edit['vetID']; ?>">
            ID: <?php echo $edit['vetID']; ?><br>
        <?php } else { ?>
            ID: <input type="text" name="vetID" required><br>
        <?php } ?>
        First Name: <input type="text" name="vetFName" value="<?php echo $edit ? $edit['vetFName'] : ''; ?>" required><br>
        Last Name: <input type="text" name="vetLName" value="<?php echo $edit ? $edit['vetLName'] : ''; ?>" required><br>
        Address: <input type="text" name="vetAddress" value="<?php echo $edit ? $edit['vetAddress'] : ''; ?>" required><br>
        Specialization: <input type="text" name="vetSpecial" value="<?php echo $edit ? $edit['vetSpecial'] : ''; ?>" required><br>
        <?php if ($edit) { ?>
            <input type="submit" name="update" value="Update">
            <a href="veterinarians.php">Cancel</a>
        <?php } else { ?>
            <input type="submit" name="add" value="Add">
        <?php } ?>
    </form>
    <hr>

    <!-- SEARCH -->
    <form method="GET">
        Search: <input type="text" name="search" value="<?php echo $search; ?>">
        <input type="submit" value="Search">
        <a href="veterinarians.php">Show All</a>
    </form>
    <br>

    <!-- LIST -->
    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th><th>First Name</th><th>Last Name</th><th>Address</th><th>Specialization</th><th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo $row['vetID']; ?></td>
            <td><?php echo $row['vetFName']; ?></td>
            <td><?php echo $row['vetLName']; ?></td>
            <td><?php echo $row['vetAddress']; ?></td>
            <td><?php echo $row['vetSpecial']; ?></td>
            <td>
                <a href="veterinarians.php?edit=<?php echo $row['vetID']; ?>">Edit</a> |
                <a href="veterinarians.php?delete=<?php echo $row['vetID']; ?>" onclick="return confirm('Delete?')">Delete</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
