<!DOCTYPE html>
<html>
<head>
    <title>Menu</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Veterinary Clinic System</h2>
    <p>Welcome, Local Admin</p>
    <hr>
    <ul>
        <li><a href="veterinarians.php">Veterinarian Management</a></li>
        <li><a href="pet_owners.php">Pet Owner Management</a></li>
        <li><a href="pets.php">Pet Management</a></li>
        <li><a href="consultations.php">Consultations Management</a></li>
        <li><a href="inquiry.php">Consultations Inquiry</a></li>
    </ul>
</body>
</html>
