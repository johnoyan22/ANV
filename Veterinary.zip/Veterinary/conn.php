<?php
session_start();

// Hardcoded database connection
$conn = mysqli_connect("localhost", "root", "", "clinic");

if (!$conn) {
    die("Database connection failed. Import Clinic.sql in phpMyAdmin first.");
}

// Check if user is logged in
if (!isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}
