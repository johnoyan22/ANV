<?php
session_start();
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/app.php';

$pageTitle = 'Main Menu';
require_once __DIR__ . '/includes/header.php';
?>

<h2>Main Menu</h2>
<?php renderMainMenu(); ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
