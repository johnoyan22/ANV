<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$patID = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$patID) {
    flash('error', 'Invalid patient ID.');
    redirect('patients/search.php');
}

$pdo = getConnection();
$stmt = $pdo->prepare('DELETE FROM patient WHERE patID = :patID');
$stmt->execute([':patID' => $patID]);

if ($stmt->rowCount() > 0) {
    flash('success', 'Patient record deleted successfully.');
} else {
    flash('error', 'Patient not found or already deleted.');
}

redirect('patients/index.php');
