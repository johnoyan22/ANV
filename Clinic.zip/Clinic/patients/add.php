<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patID    = filter_input(INPUT_POST, 'patID', FILTER_VALIDATE_INT);
    $patFName = trim($_POST['patFName'] ?? '');
    $patLName = trim($_POST['patLName'] ?? '');
    $patBDate = trim($_POST['patBDate'] ?? '');
    $patTelNo = trim($_POST['patTelNo'] ?? '');

    if (!$patID) $errors[] = 'Patient ID is required and must be a number.';
    if ($patFName === '') $errors[] = 'First name is required.';
    if ($patLName === '') $errors[] = 'Last name is required.';
    if ($patBDate === '') $errors[] = 'Birth date is required.';
    if ($patTelNo === '') $errors[] = 'Telephone number is required.';

    if (empty($errors)) {
        $pdo = getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO patient (patID, patFName, patLName, patBDate, patTelNo)
             VALUES (:patID, :patFName, :patLName, :patBDate, :patTelNo)'
        );
        try {
            $stmt->execute([
                ':patID'    => $patID,
                ':patFName' => $patFName,
                ':patLName' => $patLName,
                ':patBDate' => $patBDate,
                ':patTelNo' => $patTelNo,
            ]);
            flash('success', 'Patient record added successfully.');
            redirect('patients/index.php');
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $errors[] = 'Patient ID already exists.';
            } else {
                $errors[] = 'Failed to add patient. Please try again.';
            }
        }
    }
}

$pageTitle = 'Add Patient';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>Add Patient</h2>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <?php foreach ($errors as $error): ?>
                <div><?= e($error) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="patID">Patient ID</label>
        <input type="number" id="patID" name="patID" value="<?= e($_POST['patID'] ?? '') ?>" required>

        <label for="patFName">First Name</label>
        <input type="text" id="patFName" name="patFName" value="<?= e($_POST['patFName'] ?? '') ?>" required>

        <label for="patLName">Last Name</label>
        <input type="text" id="patLName" name="patLName" value="<?= e($_POST['patLName'] ?? '') ?>" required>

        <label for="patBDate">Birth Date</label>
        <input type="date" id="patBDate" name="patBDate" value="<?= e($_POST['patBDate'] ?? '') ?>" required>

        <label for="patTelNo">Telephone Number</label>
        <input type="text" id="patTelNo" name="patTelNo" value="<?= e($_POST['patTelNo'] ?? '') ?>" required>

        <button type="submit">Save Patient</button>
        <a href="<?= url('patients/index.php') ?>">Cancel</a>
    </form>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
