<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$pdo = getConnection();
$patient = null;
$searchId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $searchId = filter_input(INPUT_POST, 'patID', FILTER_VALIDATE_INT);
}

if ($searchId) {
    $stmt = $pdo->prepare('SELECT * FROM patient WHERE patID = :patID');
    $stmt->execute([':patID' => $searchId]);
    $patient = $stmt->fetch();
}

$pageTitle = 'Search Patient';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>Search Patient</h2>

    <form method="POST" action="">
        <label for="patID">Patient ID</label>
        <input type="number" id="patID" name="patID" value="<?= e((string) ($searchId ?: '')) ?>" required>
        <button type="submit" name="search" value="1">Search</button>
    </form>

    <?php if ($searchId && !$patient): ?>
        <div class="alert alert-error">No patient found with ID <?= e((string) $searchId) ?>.</div>
    <?php elseif ($patient): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Birth Date</th>
                    <th>Telephone</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?= e((string) $patient['patID']) ?></td>
                    <td><?= e($patient['patFName']) ?></td>
                    <td><?= e($patient['patLName']) ?></td>
                    <td><?= e($patient['patBDate']) ?></td>
                    <td><?= e($patient['patTelNo']) ?></td>
                    <td>
                        <a href="<?= url('patients/edit.php?id=' . $patient['patID']) ?>">Update</a>
                        <a href="<?= url('patients/delete.php?id=' . $patient['patID']) ?>" onclick="return confirm('Delete this patient?')">Delete</a>
                    </td>
                </tr>
            </tbody>
        </table>
    <?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
