<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$patID = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$patID) {
    flash('error', 'Invalid patient ID.');
    redirect('patients/search.php');
}

$pdo = getConnection();
$stmt = $pdo->prepare('SELECT * FROM patient WHERE patID = :patID');
$stmt->execute([':patID' => $patID]);
$patient = $stmt->fetch();

if (!$patient) {
    flash('error', 'Patient not found.');
    redirect('patients/search.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patFName = trim($_POST['patFName'] ?? '');
    $patLName = trim($_POST['patLName'] ?? '');
    $patBDate = trim($_POST['patBDate'] ?? '');
    $patTelNo = trim($_POST['patTelNo'] ?? '');

    if ($patFName === '') $errors[] = 'First name is required.';
    if ($patLName === '') $errors[] = 'Last name is required.';
    if ($patBDate === '') $errors[] = 'Birth date is required.';
    if ($patTelNo === '') $errors[] = 'Telephone number is required.';

    if (empty($errors)) {
        $stmt = $pdo->prepare(
            'UPDATE patient SET patFName = :patFName, patLName = :patLName,
             patBDate = :patBDate, patTelNo = :patTelNo
             WHERE patID = :patID'
        );
        $stmt->execute([
            ':patFName' => $patFName,
            ':patLName' => $patLName,
            ':patBDate' => $patBDate,
            ':patTelNo' => $patTelNo,
            ':patID'    => $patID,
        ]);
        flash('success', 'Patient record updated successfully.');
        redirect('patients/index.php');
    }
}

$pageTitle = 'Update Patient';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>Update Patient #<?= e((string) $patID) ?></h2>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <?php foreach ($errors as $error): ?>
                <div><?= e($error) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="patFName">First Name</label>
        <input type="text" id="patFName" name="patFName" value="<?= e($_POST['patFName'] ?? $patient['patFName']) ?>" required>

        <label for="patLName">Last Name</label>
        <input type="text" id="patLName" name="patLName" value="<?= e($_POST['patLName'] ?? $patient['patLName']) ?>" required>

        <label for="patBDate">Birth Date</label>
        <input type="date" id="patBDate" name="patBDate" value="<?= e($_POST['patBDate'] ?? $patient['patBDate']) ?>" required>

        <label for="patTelNo">Telephone Number</label>
        <input type="text" id="patTelNo" name="patTelNo" value="<?= e($_POST['patTelNo'] ?? $patient['patTelNo']) ?>" required>

        <button type="submit">Update Patient</button>
        <a href="<?= url('patients/index.php') ?>">Cancel</a>
    </form>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
