<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$pdo = getConnection();
$stmt = $pdo->query('SELECT * FROM patient ORDER BY patLName, patFName');
$patients = $stmt->fetchAll();

$pageTitle = 'View All Patients';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>All Patients</h2>
<p>
    <a href="<?= url('patients/add.php') ?>">Add Patient</a> |
    <a href="<?= url('patients/search.php') ?>">Search</a>
</p>
    <?php if (empty($patients)): ?>
        <p class="empty-state">No patient records found.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Birth Date</th>
                    <th>Telephone</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($patients as $pat): ?>
                <tr>
                    <td><?= e((string) $pat['patID']) ?></td>
                    <td><?= e($pat['patFName']) ?></td>
                    <td><?= e($pat['patLName']) ?></td>
                    <td><?= e($pat['patBDate']) ?></td>
                    <td><?= e($pat['patTelNo']) ?></td>
                    <td>
                        <a href="<?= url('patients/edit.php?id=' . $pat['patID']) ?>">Edit</a>
                        <a href="<?= url('patients/delete.php?id=' . $pat['patID']) ?>" onclick="return confirm('Delete this patient?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
