<?php

define('APP_NAME', 'Clinic Consultations Logging System');

if (!defined('BASE_URL')) {
    $docRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '');
    $appRoot = realpath(dirname(__DIR__));

    if ($docRoot && $appRoot && str_starts_with($appRoot, $docRoot)) {
        $baseUrl = str_replace('\\', '/', substr($appRoot, strlen($docRoot)));
    } else {
        $baseUrl = '';
    }

    define('BASE_URL', rtrim($baseUrl, '/'));
}

function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

function redirect(string $path): void
{
    header('Location: ' . url($path));
    exit;
}

function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function renderFlash(): void
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        echo '<div class="alert alert-' . e($flash['type']) . '">' . e($flash['message']) . '</div>';
        unset($_SESSION['flash']);
    }
}

function menuModules(): array
{
    return [
        [
            'title' => 'Doctors',
            'links' => [
                ['label' => 'Add Doctor', 'path' => 'doctors/add.php'],
                ['label' => 'Search / Update / Delete', 'path' => 'doctors/search.php'],
                ['label' => 'View All Doctors', 'path' => 'doctors/index.php'],
            ],
        ],
        [
            'title' => 'Patients',
            'links' => [
                ['label' => 'Add Patient', 'path' => 'patients/add.php'],
                ['label' => 'Search / Update / Delete', 'path' => 'patients/search.php'],
                ['label' => 'View All Patients', 'path' => 'patients/index.php'],
            ],
        ],
        [
            'title' => 'Consultations',
            'links' => [
                ['label' => 'Add Consultation', 'path' => 'consultations/add.php'],
                ['label' => 'Search / Update / Delete', 'path' => 'consultations/search.php'],
                ['label' => 'View All Consultations', 'path' => 'consultations/index.php'],
            ],
        ],
        [
            'title' => 'Inquiry & Reports',
            'links' => [
                ['label' => 'Search & Reporting', 'path' => 'inquiry/index.php'],
            ],
        ],
    ];
}

function isHomePage(): bool
{
    $script = str_replace('\\', '/', $_SERVER['PHP_SELF'] ?? '');
    return basename($script) === 'index.php'
        && !in_array(basename(dirname($script)), ['doctors', 'patients', 'consultations', 'inquiry'], true);
}

function renderHomeLink(): void
{
    if (!isHomePage()) {
        echo '<p class="page-nav"><a href="' . url('index.php') . '">Back to Main Menu</a></p>';
    }
}

function renderMainMenu(): void
{
    foreach (menuModules() as $module) {
        echo '<h3>' . e($module['title']) . '</h3><ul>';
        foreach ($module['links'] as $link) {
            echo '<li><a href="' . url($link['path']) . '">' . e($link['label']) . '</a></li>';
        }
        echo '</ul>';
    }
}
