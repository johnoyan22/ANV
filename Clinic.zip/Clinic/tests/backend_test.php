<?php
/**
 * Backend smoke test for Clinic system.
 * Run: D:\xampp\php\php.exe tests\backend_test.php
 */
declare(strict_types=1);

$root = dirname(__DIR__);
require_once $root . '/config/database.php';

$passed = 0;
$failed = 0;

function test(string $name, callable $fn): void
{
    global $passed, $failed;
    try {
        $fn();
        echo "[PASS] $name\n";
        $passed++;
    } catch (Throwable $e) {
        echo "[FAIL] $name\n       " . $e->getMessage() . "\n";
        $failed++;
    }
}

function assertTrue(bool $cond, string $msg = 'Assertion failed'): void
{
    if (!$cond) {
        throw new RuntimeException($msg);
    }
}

echo "=== Clinic Backend Test ===\n\n";

test('Database connection', function () {
    $pdo = getConnection();
    assertTrue($pdo instanceof PDO);
});

$pdo = getConnection();

// Use high IDs to avoid clashing with sample data
$testDocId = 9001;
$testPatId = 9001;
$testConsultId = 9001;

// Cleanup any leftover test data
$pdo->exec("DELETE FROM consultation WHERE consultID = $testConsultId");
$pdo->exec("DELETE FROM patient WHERE patID = $testPatId");
$pdo->exec("DELETE FROM doctor WHERE docID = $testDocId");

test('INSERT doctor', function () use ($pdo, $testDocId) {
    $stmt = $pdo->prepare(
        'INSERT INTO doctor (docID, docFName, docLName, docAddress, docSpecial)
         VALUES (:docID, :docFName, :docLName, :docAddress, :docSpecial)'
    );
    $stmt->execute([
        ':docID' => $testDocId,
        ':docFName' => 'Test',
        ':docLName' => 'Doctor',
        ':docAddress' => 'Test Address',
        ':docSpecial' => 'General Medicine',
    ]);
    assertTrue($stmt->rowCount() === 1);
});

test('SELECT doctor', function () use ($pdo, $testDocId) {
    $stmt = $pdo->prepare('SELECT * FROM doctor WHERE docID = :docID');
    $stmt->execute([':docID' => $testDocId]);
    $row = $stmt->fetch();
    assertTrue($row !== false && $row['docFName'] === 'Test');
});

test('UPDATE doctor', function () use ($pdo, $testDocId) {
    $stmt = $pdo->prepare(
        'UPDATE doctor SET docSpecial = :docSpecial WHERE docID = :docID'
    );
    $stmt->execute([':docSpecial' => 'Pediatrics', ':docID' => $testDocId]);
    $stmt = $pdo->prepare('SELECT docSpecial FROM doctor WHERE docID = :docID');
    $stmt->execute([':docID' => $testDocId]);
    assertTrue($stmt->fetchColumn() === 'Pediatrics');
});

test('INSERT patient', function () use ($pdo, $testPatId) {
    $stmt = $pdo->prepare(
        'INSERT INTO patient (patID, patFName, patLName, patBDate, patTelNo)
         VALUES (:patID, :patFName, :patLName, :patBDate, :patTelNo)'
    );
    $stmt->execute([
        ':patID' => $testPatId,
        ':patFName' => 'Test',
        ':patLName' => 'Patient',
        ':patBDate' => '2000-01-15',
        ':patTelNo' => '09999999999',
    ]);
    assertTrue($stmt->rowCount() === 1);
});

test('INSERT consultation with foreign keys', function () use ($pdo, $testConsultId, $testPatId, $testDocId) {
    $stmt = $pdo->prepare(
        'INSERT INTO consultation (consultID, patID, docID, consultDate, diagnosis, prescription)
         VALUES (:consultID, :patID, :docID, :consultDate, :diagnosis, :prescription)'
    );
    $stmt->execute([
        ':consultID' => $testConsultId,
        ':patID' => $testPatId,
        ':docID' => $testDocId,
        ':consultDate' => '2025-07-01 10:00:00',
        ':diagnosis' => 'Test diagnosis',
        ':prescription' => 'Test prescription',
    ]);
    assertTrue($stmt->rowCount() === 1);
});

test('JOIN consultation query (index page)', function () use ($pdo, $testConsultId) {
    $stmt = $pdo->prepare(
        'SELECT c.*, p.patFName, p.patLName, d.docFName, d.docLName
         FROM consultation c
         JOIN patient p ON c.patID = p.patID
         JOIN doctor d ON c.docID = d.docID
         WHERE c.consultID = :consultID'
    );
    $stmt->execute([':consultID' => $testConsultId]);
    $row = $stmt->fetch();
    assertTrue($row !== false && $row['patFName'] === 'Test');
});

test('UPDATE consultation', function () use ($pdo, $testConsultId) {
    $stmt = $pdo->prepare(
        'UPDATE consultation SET diagnosis = :diagnosis WHERE consultID = :consultID'
    );
    $stmt->execute([':diagnosis' => 'Updated diagnosis', ':consultID' => $testConsultId]);
    $stmt = $pdo->prepare('SELECT diagnosis FROM consultation WHERE consultID = :consultID');
    $stmt->execute([':consultID' => $testConsultId]);
    assertTrue($stmt->fetchColumn() === 'Updated diagnosis');
});

test('Inquiry: doctors by specialization COUNT', function () use ($pdo) {
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) AS total FROM doctor WHERE docSpecial LIKE :special'
    );
    $stmt->execute([':special' => '%Cardiology%']);
    assertTrue((int) $stmt->fetchColumn() >= 1);
});

test('Inquiry: patients by age range COUNT', function () use ($pdo) {
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) AS total FROM patient
         WHERE TIMESTAMPDIFF(YEAR, patBDate, CURDATE()) BETWEEN :ageFrom AND :ageTo'
    );
    $stmt->execute([':ageFrom' => 0, ':ageTo' => 120]);
    assertTrue((int) $stmt->fetchColumn() >= 1);
});

test('Inquiry: consultations by patient COUNT', function () use ($pdo, $testPatId) {
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) AS total FROM consultation WHERE patID = :patID'
    );
    $stmt->execute([':patID' => $testPatId]);
    assertTrue((int) $stmt->fetchColumn() === 1);
});

test('Inquiry: consultations by doctor COUNT', function () use ($pdo, $testDocId) {
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) AS total FROM consultation WHERE docID = :docID'
    );
    $stmt->execute([':docID' => $testDocId]);
    assertTrue((int) $stmt->fetchColumn() === 1);
});

test('Inquiry: consultations by date range COUNT', function () use ($pdo) {
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) AS total FROM consultation
         WHERE consultDate BETWEEN :dateFrom AND :dateTo'
    );
    $stmt->execute([
        ':dateFrom' => '2025-01-01 00:00:00',
        ':dateTo' => '2025-12-31 23:59:59',
    ]);
    assertTrue((int) $stmt->fetchColumn() >= 1);
});

test('DELETE consultation', function () use ($pdo, $testConsultId) {
    $stmt = $pdo->prepare('DELETE FROM consultation WHERE consultID = :consultID');
    $stmt->execute([':consultID' => $testConsultId]);
    assertTrue($stmt->rowCount() === 1);
});

test('DELETE patient', function () use ($pdo, $testPatId) {
    $stmt = $pdo->prepare('DELETE FROM patient WHERE patID = :patID');
    $stmt->execute([':patID' => $testPatId]);
    assertTrue($stmt->rowCount() === 1);
});

test('DELETE doctor', function () use ($pdo, $testDocId) {
    $stmt = $pdo->prepare('DELETE FROM doctor WHERE docID = :docID');
    $stmt->execute([':docID' => $testDocId]);
    assertTrue($stmt->rowCount() === 1);
});

test('Foreign key: invalid patient on consultation fails', function () use ($pdo, $testDocId) {
    $pdo->exec("DELETE FROM doctor WHERE docID = $testDocId");
    $stmt = $pdo->prepare(
        'INSERT INTO doctor (docID, docFName, docLName, docAddress, docSpecial)
         VALUES (9002, "A", "B", "C", "D")'
    );
    $stmt->execute();
    $failed = false;
    try {
        $stmt = $pdo->prepare(
            'INSERT INTO consultation (consultID, patID, docID, consultDate, diagnosis, prescription)
             VALUES (9002, 99999, 9002, "2025-07-01 10:00:00", "x", "y")'
        );
        $stmt->execute();
    } catch (PDOException $e) {
        $failed = true;
    }
    $pdo->exec('DELETE FROM doctor WHERE docID = 9002');
    assertTrue($failed, 'Expected foreign key violation');
});

test('Duplicate primary key fails', function () use ($pdo) {
    $failed = false;
    try {
        $stmt = $pdo->prepare(
            'INSERT INTO doctor (docID, docFName, docLName, docAddress, docSpecial)
             VALUES (1001, "X", "Y", "Z", "W")'
        );
        $stmt->execute();
    } catch (PDOException $e) {
        $failed = true;
    }
    assertTrue($failed, 'Expected duplicate key error');
});

// PHP syntax check all files
echo "\n=== PHP Syntax Check ===\n";
$phpFiles = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));
foreach ($phpFiles as $file) {
    if ($file->getExtension() !== 'php') {
        continue;
    }
    $path = $file->getPathname();
    if (str_contains($path, DIRECTORY_SEPARATOR . 'tests' . DIRECTORY_SEPARATOR)) {
        continue;
    }
    exec('"' . PHP_BINARY . '" -l ' . escapeshellarg($path) . ' 2>&1', $output, $code);
    if ($code !== 0) {
        echo "[FAIL] Syntax: $path\n       " . implode("\n", $output) . "\n";
        $failed++;
    }
}
echo "[PASS] All PHP files syntax OK\n";
$passed++;

echo "\n=== Summary ===\n";
echo "Passed: $passed\n";
echo "Failed: $failed\n";

exit($failed > 0 ? 1 : 0);
