# Clinic Consultations Logging System

PHP + MySQL capstone project for managing doctors, patients, and consultations.

## Requirements

- PHP 8.0+ with PDO MySQL extension
- MySQL or MariaDB (XAMPP, WAMP, or Laragon recommended)

## Setup

1. Copy this folder to your web server document root (e.g. `C:\xampp\htdocs\Clinic`).

2. Edit database credentials in `config/database.php` if needed:
   - `DB_HOST` — default `localhost`
   - `DB_NAME` — default `clinic_database`
   - `DB_USER` — default `root`
   - `DB_PASS` — default empty (XAMPP)

3. Import the database schema in phpMyAdmin or MySQL CLI:
   ```sql
   source sql/schema.sql
   source sql/sample_data.sql
   ```

4. Open in browser:
   ```
   http://localhost/Clinic/index.php
   ```

## Project Structure

| Folder / File | Description |
|---|---|
| `index.php` | Main menu |
| `doctors/` | Doctor CRUD (add, search, update, delete, view all) |
| `patients/` | Patient CRUD |
| `consultations/` | Consultation CRUD |
| `inquiry/` | Search & reporting with COUNT queries |
| `config/database.php` | PDO connection (no hard-coded queries) |
| `sql/schema.sql` | Database tables |

## Features

- Parameterized PDO queries (prevents SQL injection)
- Centralized database configuration
- Foreign key relationships between consultations, patients, and doctors
- Inquiry module uses `COUNT(*)` for all five report types
