<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$pdo = getConnection();
$results = [];
$count = 0;
$queryType = $_POST['query_type'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($queryType) {
        case 'doctors_by_special':
            $special = trim($_POST['specialization'] ?? '');
            if ($special !== '') {
                $countStmt = $pdo->prepare(
                    'SELECT COUNT(*) AS total FROM doctor WHERE docSpecial LIKE :special'
                );
                $countStmt->execute([':special' => '%' . $special . '%']);
                $count = (int) $countStmt->fetchColumn();

                $dataStmt = $pdo->prepare(
                    'SELECT * FROM doctor WHERE docSpecial LIKE :special ORDER BY docLName'
                );
                $dataStmt->execute([':special' => '%' . $special . '%']);
                $results = $dataStmt->fetchAll();
            }
            break;

        case 'patients_by_age':
            $ageFrom = filter_input(INPUT_POST, 'age_from', FILTER_VALIDATE_INT);
            $ageTo   = filter_input(INPUT_POST, 'age_to', FILTER_VALIDATE_INT);
            if ($ageFrom !== false && $ageTo !== false && $ageFrom <= $ageTo) {
                $countStmt = $pdo->prepare(
                    'SELECT COUNT(*) AS total FROM patient
                     WHERE TIMESTAMPDIFF(YEAR, patBDate, CURDATE()) BETWEEN :ageFrom AND :ageTo'
                );
                $countStmt->execute([':ageFrom' => $ageFrom, ':ageTo' => $ageTo]);
                $count = (int) $countStmt->fetchColumn();

                $dataStmt = $pdo->prepare(
                    'SELECT *, TIMESTAMPDIFF(YEAR, patBDate, CURDATE()) AS age
                     FROM patient
                     WHERE TIMESTAMPDIFF(YEAR, patBDate, CURDATE()) BETWEEN :ageFrom AND :ageTo
                     ORDER BY patLName'
                );
                $dataStmt->execute([':ageFrom' => $ageFrom, ':ageTo' => $ageTo]);
                $results = $dataStmt->fetchAll();
            }
            break;

        case 'consultations_by_patient':
            $patID = filter_input(INPUT_POST, 'patID', FILTER_VALIDATE_INT);
            if ($patID) {
                $countStmt = $pdo->prepare(
                    'SELECT COUNT(*) AS total FROM consultation WHERE patID = :patID'
                );
                $countStmt->execute([':patID' => $patID]);
                $count = (int) $countStmt->fetchColumn();

                $dataStmt = $pdo->prepare(
                    'SELECT c.*, p.patFName, p.patLName, d.docFName, d.docLName
                     FROM consultation c
                     JOIN patient p ON c.patID = p.patID
                     JOIN doctor d ON c.docID = d.docID
                     WHERE c.patID = :patID
                     ORDER BY c.consultDate DESC'
                );
                $dataStmt->execute([':patID' => $patID]);
                $results = $dataStmt->fetchAll();
            }
            break;

        case 'consultations_by_doctor':
            $docID = filter_input(INPUT_POST, 'docID', FILTER_VALIDATE_INT);
            if ($docID) {
                $countStmt = $pdo->prepare(
                    'SELECT COUNT(*) AS total FROM consultation WHERE docID = :docID'
                );
                $countStmt->execute([':docID' => $docID]);
                $count = (int) $countStmt->fetchColumn();

                $dataStmt = $pdo->prepare(
                    'SELECT c.*, p.patFName, p.patLName, d.docFName, d.docLName
                     FROM consultation c
                     JOIN patient p ON c.patID = p.patID
                     JOIN doctor d ON c.docID = d.docID
                     WHERE c.docID = :docID
                     ORDER BY c.consultDate DESC'
                );
                $dataStmt->execute([':docID' => $docID]);
                $results = $dataStmt->fetchAll();
            }
            break;

        case 'consultations_by_date':
            $dateFrom = trim($_POST['date_from'] ?? '');
            $dateTo   = trim($_POST['date_to'] ?? '');
            if ($dateFrom !== '' && $dateTo !== '') {
                $countStmt = $pdo->prepare(
                    'SELECT COUNT(*) AS total FROM consultation
                     WHERE consultDate BETWEEN :dateFrom AND :dateTo'
                );
                $countStmt->execute([
                    ':dateFrom' => $dateFrom . ' 00:00:00',
                    ':dateTo'   => $dateTo . ' 23:59:59',
                ]);
                $count = (int) $countStmt->fetchColumn();

                $dataStmt = $pdo->prepare(
                    'SELECT c.*, p.patFName, p.patLName, d.docFName, d.docLName
                     FROM consultation c
                     JOIN patient p ON c.patID = p.patID
                     JOIN doctor d ON c.docID = d.docID
                     WHERE c.consultDate BETWEEN :dateFrom AND :dateTo
                     ORDER BY c.consultDate DESC'
                );
                $dataStmt->execute([
                    ':dateFrom' => $dateFrom . ' 00:00:00',
                    ':dateTo'   => $dateTo . ' 23:59:59',
                ]);
                $results = $dataStmt->fetchAll();
            }
            break;
    }
}

$pageTitle = 'Consultations Inquiry';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>Consultations Inquiry &amp; Reporting</h2>
<p>All searches display results with a <strong>COUNT</strong> of matching records.</p>

<h3>1. Doctors by Specialization</h3>
<form method="POST">
    <input type="hidden" name="query_type" value="doctors_by_special">
    <label for="specialization">Specialization</label>
    <input type="text" id="specialization" name="specialization"
        value="<?= e($_POST['specialization'] ?? '') ?>" placeholder="e.g. Cardiology" required>
    <button type="submit">Search</button>
</form>

<h3>2. Patients by Age Range</h3>
<form method="POST">
    <input type="hidden" name="query_type" value="patients_by_age">
    <label for="age_from">Age From</label>
    <input type="number" id="age_from" name="age_from" min="0" max="150"
        value="<?= e($_POST['age_from'] ?? '') ?>" required>
    <label for="age_to">Age To</label>
    <input type="number" id="age_to" name="age_to" min="0" max="150"
        value="<?= e($_POST['age_to'] ?? '') ?>" required>
    <button type="submit">Search</button>
</form>

<h3>3. Consultations by Patient ID</h3>
<form method="POST">
    <input type="hidden" name="query_type" value="consultations_by_patient">
    <label for="patID">Patient ID</label>
    <input type="number" id="patID" name="patID"
        value="<?= e($_POST['patID'] ?? '') ?>" required>
    <button type="submit">Search</button>
</form>

<h3>4. Consultations by Doctor ID</h3>
<form method="POST">
    <input type="hidden" name="query_type" value="consultations_by_doctor">
    <label for="docID">Doctor ID</label>
    <input type="number" id="docID" name="docID"
        value="<?= e($_POST['docID'] ?? '') ?>" required>
    <button type="submit">Search</button>
</form>

<h3>5. Consultations by Date Range</h3>
<form method="POST">
    <input type="hidden" name="query_type" value="consultations_by_date">
    <label for="date_from">Date From</label>
    <input type="date" id="date_from" name="date_from"
        value="<?= e($_POST['date_from'] ?? '') ?>" required>
    <label for="date_to">Date To</label>
    <input type="date" id="date_to" name="date_to"
        value="<?= e($_POST['date_to'] ?? '') ?>" required>
    <button type="submit">Search</button>
</form>

<?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && $queryType !== ''): ?>
<h3>Query Results</h3>
    <span class="count-badge">COUNT: <?= e((string) $count) ?> record(s) found</span>

    <?php if (empty($results)): ?>
        <p class="empty-state">No matching records.</p>
    <?php else: ?>

        <?php if ($queryType === 'doctors_by_special'): ?>
        <table>
            <thead>
                <tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Address</th><th>Specialization</th></tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row): ?>
                <tr>
                    <td><?= e((string) $row['docID']) ?></td>
                    <td><?= e($row['docFName']) ?></td>
                    <td><?= e($row['docLName']) ?></td>
                    <td><?= e($row['docAddress']) ?></td>
                    <td><?= e($row['docSpecial']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <?php elseif ($queryType === 'patients_by_age'): ?>
        <table>
            <thead>
                <tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Birth Date</th><th>Age</th><th>Telephone</th></tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row): ?>
                <tr>
                    <td><?= e((string) $row['patID']) ?></td>
                    <td><?= e($row['patFName']) ?></td>
                    <td><?= e($row['patLName']) ?></td>
                    <td><?= e($row['patBDate']) ?></td>
                    <td><?= e((string) $row['age']) ?></td>
                    <td><?= e($row['patTelNo']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <?php else: ?>
        <table>
            <thead>
                <tr><th>ID</th><th>Patient</th><th>Doctor</th><th>Date/Time</th><th>Diagnosis</th><th>Prescription</th></tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row): ?>
                <tr>
                    <td><?= e((string) $row['consultID']) ?></td>
                    <td><?= e($row['patFName'] . ' ' . $row['patLName']) ?></td>
                    <td><?= e('Dr. ' . $row['docFName'] . ' ' . $row['docLName']) ?></td>
                    <td><?= e($row['consultDate']) ?></td>
                    <td><?= e($row['diagnosis']) ?></td>
                    <td><?= e($row['prescription']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>

    <?php endif; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
