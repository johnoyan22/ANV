<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$consultID = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$consultID) {
    flash('error', 'Invalid consultation ID.');
    redirect('consultations/search.php');
}

$pdo = getConnection();
$stmt = $pdo->prepare('SELECT * FROM consultation WHERE consultID = :consultID');
$stmt->execute([':consultID' => $consultID]);
$consultation = $stmt->fetch();

if (!$consultation) {
    flash('error', 'Consultation not found.');
    redirect('consultations/search.php');
}

$patients = $pdo->query('SELECT patID, patFName, patLName FROM patient ORDER BY patLName')->fetchAll();
$doctors  = $pdo->query('SELECT docID, docFName, docLName FROM doctor ORDER BY docLName')->fetchAll();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patID        = filter_input(INPUT_POST, 'patID', FILTER_VALIDATE_INT);
    $docID        = filter_input(INPUT_POST, 'docID', FILTER_VALIDATE_INT);
    $consultDate  = trim($_POST['consultDate'] ?? '');
    $diagnosis    = trim($_POST['diagnosis'] ?? '');
    $prescription = trim($_POST['prescription'] ?? '');

    if (!$patID) $errors[] = 'Please select a patient.';
    if (!$docID) $errors[] = 'Please select a doctor.';
    if ($consultDate === '') $errors[] = 'Consultation date/time is required.';
    if ($diagnosis === '') $errors[] = 'Diagnosis is required.';
    if ($prescription === '') $errors[] = 'Prescription is required.';

    if ($consultDate !== '') {
        $consultDate = str_replace('T', ' ', $consultDate);
        if (strlen($consultDate) === 16) {
            $consultDate .= ':00';
        }
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare(
            'UPDATE consultation SET patID = :patID, docID = :docID, consultDate = :consultDate,
             diagnosis = :diagnosis, prescription = :prescription
             WHERE consultID = :consultID'
        );
        try {
            $stmt->execute([
                ':patID'        => $patID,
                ':docID'        => $docID,
                ':consultDate'  => $consultDate,
                ':diagnosis'    => $diagnosis,
                ':prescription' => $prescription,
                ':consultID'    => $consultID,
            ]);
            flash('success', 'Consultation record updated successfully.');
            redirect('consultations/index.php');
        } catch (PDOException $e) {
            $errors[] = 'Failed to update. Check patient and doctor references.';
        }
    }
}

$datetimeLocal = $consultation['consultDate'];
$datetimeLocal = str_replace(' ', 'T', substr($datetimeLocal, 0, 16));

$pageTitle = 'Update Consultation';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>Update Consultation #<?= e((string) $consultID) ?></h2>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <?php foreach ($errors as $error): ?>
                <div><?= e($error) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="patID">Patient</label>
        <select id="patID" name="patID" required>
            <?php foreach ($patients as $p): ?>
                <option value="<?= e((string) $p['patID']) ?>"
                    <?= (($consultation['patID'] == $p['patID']) || (($_POST['patID'] ?? '') == $p['patID'])) ? 'selected' : '' ?>>
                    <?= e($p['patFName'] . ' ' . $p['patLName'] . ' (#' . $p['patID'] . ')') ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="docID">Doctor</label>
        <select id="docID" name="docID" required>
            <?php foreach ($doctors as $d): ?>
                <option value="<?= e((string) $d['docID']) ?>"
                    <?= (($consultation['docID'] == $d['docID']) || (($_POST['docID'] ?? '') == $d['docID'])) ? 'selected' : '' ?>>
                    <?= e('Dr. ' . $d['docFName'] . ' ' . $d['docLName'] . ' (#' . $d['docID'] . ')') ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="consultDate">Consultation Date &amp; Time</label>
        <input type="datetime-local" id="consultDate" name="consultDate"
            value="<?= e($_POST['consultDate'] ?? $datetimeLocal) ?>" required>

        <label for="diagnosis">Diagnosis</label>
        <textarea id="diagnosis" name="diagnosis" required><?= e($_POST['diagnosis'] ?? $consultation['diagnosis']) ?></textarea>

        <label for="prescription">Prescription</label>
        <textarea id="prescription" name="prescription" required><?= e($_POST['prescription'] ?? $consultation['prescription']) ?></textarea>

        <button type="submit">Update Consultation</button>
        <a href="<?= url('consultations/index.php') ?>">Cancel</a>
    </form>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
