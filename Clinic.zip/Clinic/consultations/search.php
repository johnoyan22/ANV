<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$pdo = getConnection();
$consultation = null;
$searchId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $searchId = filter_input(INPUT_POST, 'consultID', FILTER_VALIDATE_INT);
}

if ($searchId) {
    $stmt = $pdo->prepare(
        'SELECT c.*, p.patFName, p.patLName, d.docFName, d.docLName
         FROM consultation c
         JOIN patient p ON c.patID = p.patID
         JOIN doctor d ON c.docID = d.docID
         WHERE c.consultID = :consultID'
    );
    $stmt->execute([':consultID' => $searchId]);
    $consultation = $stmt->fetch();
}

$pageTitle = 'Search Consultation';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>Search Consultation</h2>

    <form method="POST" action="">
        <label for="consultID">Consultation ID</label>
        <input type="number" id="consultID" name="consultID" value="<?= e((string) ($searchId ?: '')) ?>" required>
        <button type="submit" name="search" value="1">Search</button>
    </form>

    <?php if ($searchId && !$consultation): ?>
        <div class="alert alert-error">No consultation found with ID <?= e((string) $searchId) ?>.</div>
    <?php elseif ($consultation): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Patient</th>
                    <th>Doctor</th>
                    <th>Date/Time</th>
                    <th>Diagnosis</th>
                    <th>Prescription</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?= e((string) $consultation['consultID']) ?></td>
                    <td><?= e($consultation['patFName'] . ' ' . $consultation['patLName']) ?></td>
                    <td><?= e('Dr. ' . $consultation['docFName'] . ' ' . $consultation['docLName']) ?></td>
                    <td><?= e($consultation['consultDate']) ?></td>
                    <td><?= e($consultation['diagnosis']) ?></td>
                    <td><?= e($consultation['prescription']) ?></td>
                    <td>
                        <a href="<?= url('consultations/edit.php?id=' . $consultation['consultID']) ?>">Update</a>
                        <a href="<?= url('consultations/delete.php?id=' . $consultation['consultID']) ?>" onclick="return confirm('Delete this consultation?')">Delete</a>
                    </td>
                </tr>
            </tbody>
        </table>
    <?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
