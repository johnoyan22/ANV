<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$pdo = getConnection();
$stmt = $pdo->query(
    'SELECT c.*, p.patFName, p.patLName, d.docFName, d.docLName
     FROM consultation c
     JOIN patient p ON c.patID = p.patID
     JOIN doctor d ON c.docID = d.docID
     ORDER BY c.consultDate DESC'
);
$consultations = $stmt->fetchAll();

$pageTitle = 'View All Consultations';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>All Consultations</h2>
<p>
    <a href="<?= url('consultations/add.php') ?>">Add Consultation</a> |
    <a href="<?= url('consultations/search.php') ?>">Search</a>
</p>
    <?php if (empty($consultations)): ?>
        <p class="empty-state">No consultation records found.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Patient</th>
                    <th>Doctor</th>
                    <th>Date/Time</th>
                    <th>Diagnosis</th>
                    <th>Prescription</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($consultations as $con): ?>
                <tr>
                    <td><?= e((string) $con['consultID']) ?></td>
                    <td><?= e($con['patFName'] . ' ' . $con['patLName']) ?></td>
                    <td><?= e('Dr. ' . $con['docFName'] . ' ' . $con['docLName']) ?></td>
                    <td><?= e($con['consultDate']) ?></td>
                    <td><?= e($con['diagnosis']) ?></td>
                    <td><?= e($con['prescription']) ?></td>
                    <td>
                        <a href="<?= url('consultations/edit.php?id=' . $con['consultID']) ?>">Edit</a>
                        <a href="<?= url('consultations/delete.php?id=' . $con['consultID']) ?>" onclick="return confirm('Delete this consultation?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
