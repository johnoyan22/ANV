<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$pdo = getConnection();
$patients = $pdo->query('SELECT patID, patFName, patLName FROM patient ORDER BY patLName')->fetchAll();
$doctors  = $pdo->query('SELECT docID, docFName, docLName FROM doctor ORDER BY docLName')->fetchAll();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $consultID    = filter_input(INPUT_POST, 'consultID', FILTER_VALIDATE_INT);
    $patID        = filter_input(INPUT_POST, 'patID', FILTER_VALIDATE_INT);
    $docID        = filter_input(INPUT_POST, 'docID', FILTER_VALIDATE_INT);
    $consultDate  = trim($_POST['consultDate'] ?? '');
    $diagnosis    = trim($_POST['diagnosis'] ?? '');
    $prescription = trim($_POST['prescription'] ?? '');

    if (!$consultID) $errors[] = 'Consultation ID is required.';
    if (!$patID) $errors[] = 'Please select a patient.';
    if (!$docID) $errors[] = 'Please select a doctor.';
    if ($consultDate === '') $errors[] = 'Consultation date/time is required.';
    if ($diagnosis === '') $errors[] = 'Diagnosis is required.';
    if ($prescription === '') $errors[] = 'Prescription is required.';

    if ($consultDate !== '') {
        $consultDate = str_replace('T', ' ', $consultDate);
        if (strlen($consultDate) === 16) {
            $consultDate .= ':00';
        }
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare(
            'INSERT INTO consultation (consultID, patID, docID, consultDate, diagnosis, prescription)
             VALUES (:consultID, :patID, :docID, :consultDate, :diagnosis, :prescription)'
        );
        try {
            $stmt->execute([
                ':consultID'    => $consultID,
                ':patID'        => $patID,
                ':docID'        => $docID,
                ':consultDate'  => $consultDate,
                ':diagnosis'    => $diagnosis,
                ':prescription' => $prescription,
            ]);
            flash('success', 'Consultation record added successfully.');
            redirect('consultations/index.php');
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $errors[] = 'Consultation ID already exists or invalid patient/doctor reference.';
            } else {
                $errors[] = 'Failed to add consultation. Please try again.';
            }
        }
    }
}

$pageTitle = 'Add Consultation';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>Add Consultation</h2>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <?php foreach ($errors as $error): ?>
                <div><?= e($error) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (empty($patients) || empty($doctors)): ?>
        <div class="alert alert-info">
            You need at least one patient and one doctor before adding a consultation.
            <a href="<?= url('patients/add.php') ?>">Add Patient</a> |
            <a href="<?= url('doctors/add.php') ?>">Add Doctor</a>
        </div>
    <?php else: ?>
    <form method="POST" action="">
        <label for="consultID">Consultation ID</label>
        <input type="number" id="consultID" name="consultID" value="<?= e($_POST['consultID'] ?? '') ?>" required>

        <label for="patID">Patient</label>
        <select id="patID" name="patID" required>
            <option value="">-- Select Patient --</option>
            <?php foreach ($patients as $p): ?>
                <option value="<?= e((string) $p['patID']) ?>" <?= (($_POST['patID'] ?? '') == $p['patID']) ? 'selected' : '' ?>>
                    <?= e($p['patFName'] . ' ' . $p['patLName'] . ' (#' . $p['patID'] . ')') ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="docID">Doctor</label>
        <select id="docID" name="docID" required>
            <option value="">-- Select Doctor --</option>
            <?php foreach ($doctors as $d): ?>
                <option value="<?= e((string) $d['docID']) ?>" <?= (($_POST['docID'] ?? '') == $d['docID']) ? 'selected' : '' ?>>
                    <?= e('Dr. ' . $d['docFName'] . ' ' . $d['docLName'] . ' (#' . $d['docID'] . ')') ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="consultDate">Consultation Date &amp; Time</label>
        <input type="datetime-local" id="consultDate" name="consultDate" value="<?= e($_POST['consultDate'] ?? '') ?>" required>

        <label for="diagnosis">Diagnosis</label>
        <textarea id="diagnosis" name="diagnosis" required><?= e($_POST['diagnosis'] ?? '') ?></textarea>

        <label for="prescription">Prescription</label>
        <textarea id="prescription" name="prescription" required><?= e($_POST['prescription'] ?? '') ?></textarea>

        <button type="submit">Save Consultation</button>
        <a href="<?= url('consultations/index.php') ?>">Cancel</a>
    </form>
    <?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
