<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$consultID = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$consultID) {
    flash('error', 'Invalid consultation ID.');
    redirect('consultations/search.php');
}

$pdo = getConnection();
$stmt = $pdo->prepare('DELETE FROM consultation WHERE consultID = :consultID');
$stmt->execute([':consultID' => $consultID]);

if ($stmt->rowCount() > 0) {
    flash('success', 'Consultation record deleted successfully.');
} else {
    flash('error', 'Consultation not found or already deleted.');
}

redirect('consultations/index.php');
