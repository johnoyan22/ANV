<?php
if (!defined('DB_HOST')) {
    require_once __DIR__ . '/../config/database.php';
}
if (!function_exists('url')) {
    require_once __DIR__ . '/../config/app.php';
}
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= url('assets/style.css') ?>">
</head>
<body>
    <h1><?= e(APP_NAME) ?></h1>
    <?php renderHomeLink(); ?>
    <?php renderFlash(); ?>
