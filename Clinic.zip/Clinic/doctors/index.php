<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$pdo = getConnection();
$stmt = $pdo->query('SELECT * FROM doctor ORDER BY docLName, docFName');
$doctors = $stmt->fetchAll();

$pageTitle = 'View All Doctors';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>All Doctors</h2>
<p>
    <a href="<?= url('doctors/add.php') ?>">Add Doctor</a> |
    <a href="<?= url('doctors/search.php') ?>">Search</a>
</p>
    <?php if (empty($doctors)): ?>
        <p class="empty-state">No doctor records found.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Address</th>
                    <th>Specialization</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($doctors as $doc): ?>
                <tr>
                    <td><?= e((string) $doc['docID']) ?></td>
                    <td><?= e($doc['docFName']) ?></td>
                    <td><?= e($doc['docLName']) ?></td>
                    <td><?= e($doc['docAddress']) ?></td>
                    <td><?= e($doc['docSpecial']) ?></td>
                    <td>
                        <a href="<?= url('doctors/edit.php?id=' . $doc['docID']) ?>">Edit</a>
                        <a href="<?= url('doctors/delete.php?id=' . $doc['docID']) ?>" onclick="return confirm('Delete this doctor?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
