<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $docID      = filter_input(INPUT_POST, 'docID', FILTER_VALIDATE_INT);
    $docFName   = trim($_POST['docFName'] ?? '');
    $docLName   = trim($_POST['docLName'] ?? '');
    $docAddress = trim($_POST['docAddress'] ?? '');
    $docSpecial = trim($_POST['docSpecial'] ?? '');

    if (!$docID) {
        $errors[] = 'Doctor ID is required and must be a number.';
    }
    if ($docFName === '') {
        $errors[] = 'First name is required.';
    }
    if ($docLName === '') {
        $errors[] = 'Last name is required.';
    }
    if ($docAddress === '') {
        $errors[] = 'Address is required.';
    }
    if ($docSpecial === '') {
        $errors[] = 'Specialization is required.';
    }

    if (empty($errors)) {
        $pdo = getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO doctor (docID, docFName, docLName, docAddress, docSpecial)
             VALUES (:docID, :docFName, :docLName, :docAddress, :docSpecial)'
        );
        try {
            $stmt->execute([
                ':docID'      => $docID,
                ':docFName'   => $docFName,
                ':docLName'   => $docLName,
                ':docAddress' => $docAddress,
                ':docSpecial' => $docSpecial,
            ]);
            flash('success', 'Doctor record added successfully.');
            redirect('doctors/index.php');
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $errors[] = 'Doctor ID already exists.';
            } else {
                $errors[] = 'Failed to add doctor. Please try again.';
            }
        }
    }
}

$pageTitle = 'Add Doctor';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>Add Doctor</h2>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <?php foreach ($errors as $error): ?>
                <div><?= e($error) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="docID">Doctor ID / License No.</label>
        <input type="number" id="docID" name="docID" value="<?= e($_POST['docID'] ?? '') ?>" required>

        <label for="docFName">First Name</label>
        <input type="text" id="docFName" name="docFName" value="<?= e($_POST['docFName'] ?? '') ?>" required>

        <label for="docLName">Last Name</label>
        <input type="text" id="docLName" name="docLName" value="<?= e($_POST['docLName'] ?? '') ?>" required>

        <label for="docAddress">Address</label>
        <input type="text" id="docAddress" name="docAddress" value="<?= e($_POST['docAddress'] ?? '') ?>" required>

        <label for="docSpecial">Specialization</label>
        <input type="text" id="docSpecial" name="docSpecial" value="<?= e($_POST['docSpecial'] ?? '') ?>" required>

        <button type="submit">Save Doctor</button>
        <a href="<?= url('doctors/index.php') ?>">Cancel</a>
    </form>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
