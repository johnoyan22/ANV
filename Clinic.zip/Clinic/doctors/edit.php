<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$docID = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$docID) {
    flash('error', 'Invalid doctor ID.');
    redirect('doctors/search.php');
}

$pdo = getConnection();
$stmt = $pdo->prepare('SELECT * FROM doctor WHERE docID = :docID');
$stmt->execute([':docID' => $docID]);
$doctor = $stmt->fetch();

if (!$doctor) {
    flash('error', 'Doctor not found.');
    redirect('doctors/search.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $docFName   = trim($_POST['docFName'] ?? '');
    $docLName   = trim($_POST['docLName'] ?? '');
    $docAddress = trim($_POST['docAddress'] ?? '');
    $docSpecial = trim($_POST['docSpecial'] ?? '');

    if ($docFName === '') $errors[] = 'First name is required.';
    if ($docLName === '') $errors[] = 'Last name is required.';
    if ($docAddress === '') $errors[] = 'Address is required.';
    if ($docSpecial === '') $errors[] = 'Specialization is required.';

    if (empty($errors)) {
        $stmt = $pdo->prepare(
            'UPDATE doctor SET docFName = :docFName, docLName = :docLName,
             docAddress = :docAddress, docSpecial = :docSpecial
             WHERE docID = :docID'
        );
        $stmt->execute([
            ':docFName'   => $docFName,
            ':docLName'   => $docLName,
            ':docAddress' => $docAddress,
            ':docSpecial' => $docSpecial,
            ':docID'      => $docID,
        ]);
        flash('success', 'Doctor record updated successfully.');
        redirect('doctors/index.php');
    }
}

$pageTitle = 'Update Doctor';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>Update Doctor #<?= e((string) $docID) ?></h2>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <?php foreach ($errors as $error): ?>
                <div><?= e($error) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="docFName">First Name</label>
        <input type="text" id="docFName" name="docFName" value="<?= e($_POST['docFName'] ?? $doctor['docFName']) ?>" required>

        <label for="docLName">Last Name</label>
        <input type="text" id="docLName" name="docLName" value="<?= e($_POST['docLName'] ?? $doctor['docLName']) ?>" required>

        <label for="docAddress">Address</label>
        <input type="text" id="docAddress" name="docAddress" value="<?= e($_POST['docAddress'] ?? $doctor['docAddress']) ?>" required>

        <label for="docSpecial">Specialization</label>
        <input type="text" id="docSpecial" name="docSpecial" value="<?= e($_POST['docSpecial'] ?? $doctor['docSpecial']) ?>" required>

        <button type="submit">Update Doctor</button>
        <a href="<?= url('doctors/index.php') ?>">Cancel</a>
    </form>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
