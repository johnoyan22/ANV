<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$pdo = getConnection();
$doctor = null;
$searchId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $searchId = filter_input(INPUT_POST, 'docID', FILTER_VALIDATE_INT);
}

if ($searchId) {
    $stmt = $pdo->prepare('SELECT * FROM doctor WHERE docID = :docID');
    $stmt->execute([':docID' => $searchId]);
    $doctor = $stmt->fetch();
}

$pageTitle = 'Search Doctor';
require_once __DIR__ . '/../includes/header.php';
?>

<h2>Search Doctor</h2>

    <form method="POST" action="">
        <label for="docID">Doctor ID</label>
        <input type="number" id="docID" name="docID" value="<?= e((string) ($searchId ?: '')) ?>" required>
        <button type="submit" name="search" value="1">Search</button>
    </form>

    <?php if ($searchId && !$doctor): ?>
        <div class="alert alert-error">No doctor found with ID <?= e((string) $searchId) ?>.</div>
    <?php elseif ($doctor): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Address</th>
                    <th>Specialization</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?= e((string) $doctor['docID']) ?></td>
                    <td><?= e($doctor['docFName']) ?></td>
                    <td><?= e($doctor['docLName']) ?></td>
                    <td><?= e($doctor['docAddress']) ?></td>
                    <td><?= e($doctor['docSpecial']) ?></td>
                    <td>
                        <a href="<?= url('doctors/edit.php?id=' . $doctor['docID']) ?>">Update</a>
                        <a href="<?= url('doctors/delete.php?id=' . $doctor['docID']) ?>" onclick="return confirm('Delete this doctor?')">Delete</a>
                    </td>
                </tr>
            </tbody>
        </table>
    <?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
