<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

$docID = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$docID) {
    flash('error', 'Invalid doctor ID.');
    redirect('doctors/search.php');
}

$pdo = getConnection();
$stmt = $pdo->prepare('DELETE FROM doctor WHERE docID = :docID');
$stmt->execute([':docID' => $docID]);

if ($stmt->rowCount() > 0) {
    flash('success', 'Doctor record deleted successfully.');
} else {
    flash('error', 'Doctor not found or already deleted.');
}

redirect('doctors/index.php');
