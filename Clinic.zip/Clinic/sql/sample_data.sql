USE clinic_database;

INSERT INTO doctor (docID, docFName, docLName, docAddress, docSpecial) VALUES
(1001, 'Maria', 'Santos', '123 Health St, Cebu City', 'Cardiology'),
(1002, 'Juan', 'Reyes', '456 Medical Ave, Cebu City', 'Pediatrics'),
(1003, 'Ana', 'Garcia', '789 Wellness Rd, Mandaue', 'General Medicine');

INSERT INTO patient (patID, patFName, patLName, patBDate, patTelNo) VALUES
(2001, 'Pedro', 'Cruz', '1990-05-15', '09171234567'),
(2002, 'Rosa', 'Lim', '1985-08-22', '09181234567'),
(2003, 'Carlos', 'Tan', '2010-03-10', '09191234567'),
(2004, 'Elena', 'Go', '1975-11-30', '09201234567');

INSERT INTO consultation (consultID, patID, docID, consultDate, diagnosis, prescription) VALUES
(3001, 2001, 1001, '2025-06-01 09:30:00', 'Mild hypertension', 'Amlodipine 5mg once daily'),
(3002, 2002, 1003, '2025-06-05 14:00:00', 'Upper respiratory infection', 'Paracetamol 500mg every 6 hours'),
(3003, 2003, 1002, '2025-06-10 10:15:00', 'Common cold', 'Rest and fluids, Vitamin C'),
(3004, 2001, 1001, '2025-06-15 11:00:00', 'Follow-up: blood pressure stable', 'Continue current medication');
