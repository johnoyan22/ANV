CREATE DATABASE IF NOT EXISTS clinic_database;
USE clinic_database;

CREATE TABLE IF NOT EXISTS doctor (
    docID       INT PRIMARY KEY,
    docFName    VARCHAR(100) NOT NULL,
    docLName    VARCHAR(100) NOT NULL,
    docAddress  VARCHAR(255) NOT NULL,
    docSpecial  VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS patient (
    patID       INT PRIMARY KEY,
    patFName    VARCHAR(100) NOT NULL,
    patLName    VARCHAR(100) NOT NULL,
    patBDate    DATE NOT NULL,
    patTelNo    VARCHAR(20) NOT NULL
);

CREATE TABLE IF NOT EXISTS consultation (
    consultID     INT PRIMARY KEY,
    patID         INT NOT NULL,
    docID         INT NOT NULL,
    consultDate   DATETIME NOT NULL,
    diagnosis     TEXT NOT NULL,
    prescription  TEXT NOT NULL,
    FOREIGN KEY (patID) REFERENCES patient(patID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (docID) REFERENCES doctor(docID) ON DELETE CASCADE ON UPDATE CASCADE
);
