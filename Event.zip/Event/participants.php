<?php
require_once 'config.php';

$pageTitle = 'Participants';
$message = '';
$error = '';

$eventsList = $pdo->query("SELECT evCode, evName FROM Events ORDER BY evCode")->fetchAll();

if (isset($_POST['add_participant'])) {
    $partID = (int)$_POST['partID'];
    $evCode = (int)$_POST['evCode'];
    $partFName = trim($_POST['partFName']);
    $partLName = trim($_POST['partLName']);
    $partDRate = (float)$_POST['partDRate'];

    try {
        $stmt = $pdo->prepare("INSERT INTO Participants (partID, evCode, partFName, partLName, partDRate) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$partID, $evCode, $partFName, $partLName, $partDRate]);
        $message = 'Participant added.';
    } catch (PDOException $e) {
        $error = $e->getMessage();
    }
}

if (isset($_POST['update_participant'])) {
    $partID = (int)$_POST['partID'];
    $evCode = (int)$_POST['evCode'];
    $partFName = trim($_POST['partFName']);
    $partLName = trim($_POST['partLName']);
    $partDRate = (float)$_POST['partDRate'];

    try {
        $stmt = $pdo->prepare("UPDATE Participants SET evCode=?, partFName=?, partLName=?, partDRate=? WHERE partID=?");
        $stmt->execute([$evCode, $partFName, $partLName, $partDRate, $partID]);
        $message = 'Participant updated.';
    } catch (PDOException $e) {
        $error = $e->getMessage();
    }
}

if (isset($_POST['delete_participant'])) {
    $partID = (int)$_POST['partID'];
    try {
        $stmt = $pdo->prepare("DELETE FROM Participants WHERE partID=?");
        $stmt->execute([$partID]);
        $message = 'Participant deleted.';
    } catch (PDOException $e) {
        $error = $e->getMessage();
    }
}

$searchResult = null;
$searchID = '';
if (isset($_GET['search']) && $_GET['search'] !== '') {
    $searchID = (int)$_GET['search'];
    $stmt = $pdo->prepare("SELECT * FROM Participants WHERE partID=?");
    $stmt->execute([$searchID]);
    $searchResult = $stmt->fetch();
}

$participants = $pdo->query("
    SELECT p.*, e.evName
    FROM Participants p
    LEFT JOIN Events e ON p.evCode = e.evCode
    ORDER BY p.partID
")->fetchAll();

require_once 'includes/header.php';
?>
<h1>Participants</h1>

<?php if ($message): ?><div class="msg ok"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error): ?><div class="msg error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<h2>Add</h2>
<form method="POST">
    <p><label>ID</label> <input type="number" name="partID" required></p>
    <p><label>Event</label>
        <select name="evCode" required>
            <option value="">-- select --</option>
            <?php foreach ($eventsList as $ev): ?>
            <option value="<?= $ev['evCode'] ?>"><?= $ev['evCode'] ?> - <?= htmlspecialchars($ev['evName']) ?></option>
            <?php endforeach; ?>
        </select>
    </p>
    <p><label>First name</label> <input type="text" name="partFName" required></p>
    <p><label>Last name</label> <input type="text" name="partLName" required></p>
    <p><label>Discount</label> <input type="number" step="0.01" name="partDRate" value="0" required></p>
    <p><button type="submit" name="add_participant">Add</button></p>
</form>

<hr>

<h2>Search / Update / Delete</h2>
<form method="GET">
    <p><label>ID</label> <input type="number" name="search" value="<?= htmlspecialchars($searchID) ?>" required> <button type="submit">Search</button></p>
</form>

<?php if ($searchResult): ?>
<form method="POST">
    <input type="hidden" name="partID" value="<?= $searchResult['partID'] ?>">
    <p><label>ID</label> <?= $searchResult['partID'] ?></p>
    <p><label>Event</label>
        <select name="evCode" required>
            <?php foreach ($eventsList as $ev): ?>
            <option value="<?= $ev['evCode'] ?>" <?= $searchResult['evCode'] == $ev['evCode'] ? 'selected' : '' ?>>
                <?= $ev['evCode'] ?> - <?= htmlspecialchars($ev['evName']) ?>
            </option>
            <?php endforeach; ?>
        </select>
    </p>
    <p><label>First name</label> <input type="text" name="partFName" value="<?= htmlspecialchars($searchResult['partFName']) ?>" required></p>
    <p><label>Last name</label> <input type="text" name="partLName" value="<?= htmlspecialchars($searchResult['partLName']) ?>" required></p>
    <p><label>Discount</label> <input type="number" step="0.01" name="partDRate" value="<?= $searchResult['partDRate'] ?>" required></p>
    <p>
        <button type="submit" name="update_participant">Update</button>
        <button type="submit" name="delete_participant" onclick="return confirm('Delete?')">Delete</button>
    </p>
</form>
<?php elseif (isset($_GET['search'])): ?>
<p>Not found.</p>
<?php endif; ?>

<hr>

<h2>All Participants</h2>
<table>
    <tr>
        <th>ID</th>
        <th>Event</th>
        <th>First name</th>
        <th>Last name</th>
        <th>Discount</th>
    </tr>
    <?php foreach ($participants as $p): ?>
    <tr>
        <td><?= $p['partID'] ?></td>
        <td><?= htmlspecialchars($p['evName'] ?? '') ?></td>
        <td><?= htmlspecialchars($p['partFName']) ?></td>
        <td><?= htmlspecialchars($p['partLName']) ?></td>
        <td><?= number_format($p['partDRate'], 2) ?></td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($participants)): ?>
    <tr><td colspan="5">No participants.</td></tr>
    <?php endif; ?>
</table>

</body>
</html>
