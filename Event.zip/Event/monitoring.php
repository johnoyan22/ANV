<?php
require_once 'config.php';

$pageTitle = 'Monitoring';

$eventNames = $pdo->query("SELECT DISTINCT evName FROM Events ORDER BY evName")->fetchAll(PDO::FETCH_COLUMN);
$filterName = isset($_GET['evName']) ? trim($_GET['evName']) : '';

$sql = "
    SELECT e.evName, p.partFName, p.partLName, r.regDate, r.regPaid, e.evRFee
    FROM Registration r
    JOIN Participants p ON r.partID = p.partID
    JOIN Events e ON p.evCode = e.evCode
";
$params = [];

if ($filterName !== '') {
    $sql .= " WHERE e.evName = ?";
    $params[] = $filterName;
}

$sql .= " ORDER BY r.regDate DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$records = $stmt->fetchAll();

$count = count($records);
$sumPaid = 0;
$evRFee = 0;

foreach ($records as $row) {
    $sumPaid += $row['regPaid'];
}

if ($filterName !== '' && $count > 0) {
    $evRFee = $records[0]['evRFee'];
} elseif ($filterName !== '') {
    $feeStmt = $pdo->prepare("SELECT evRFee FROM Events WHERE evName = ? LIMIT 1");
    $feeStmt->execute([$filterName]);
    $feeRow = $feeStmt->fetch();
    $evRFee = $feeRow ? $feeRow['evRFee'] : 0;
}

$totalDiscount = ($count * $evRFee) - $sumPaid;

require_once 'includes/header.php';
?>
<h1>Monitoring</h1>

<h2>Filter</h2>
<form method="GET">
    <p><label>Event</label>
        <select name="evName">
            <option value="">All events</option>
            <?php foreach ($eventNames as $name): ?>
            <option value="<?= htmlspecialchars($name) ?>" <?= $filterName === $name ? 'selected' : '' ?>>
                <?= htmlspecialchars($name) ?>
            </option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Filter</button>
    </p>
</form>

<hr>

<h2>Records</h2>
<table>
    <tr>
        <th>Event</th>
        <th>Participant</th>
        <th>Date</th>
        <th>Fee paid</th>
    </tr>
    <?php foreach ($records as $row): ?>
    <tr>
        <td><?= htmlspecialchars($row['evName']) ?></td>
        <td><?= htmlspecialchars($row['partFName'] . ' ' . $row['partLName']) ?></td>
        <td><?= $row['regDate'] ?></td>
        <td><?= number_format($row['regPaid'], 2) ?></td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($records)): ?>
    <tr><td colspan="4">No records.</td></tr>
    <?php endif; ?>
</table>

<hr>

<h2>Summary</h2>
<p>Count: <strong><?= $count ?></strong></p>
<p>Total paid: <strong><?= number_format($sumPaid, 2) ?></strong></p>
<?php if ($filterName !== ''): ?>
<p>Event fee: <strong><?= number_format($evRFee, 2) ?></strong></p>
<p>Total discounts: <strong><?= number_format($totalDiscount, 2) ?></strong> (<?= $count ?> × <?= number_format($evRFee, 2) ?> − <?= number_format($sumPaid, 2) ?>)</p>
<?php else: ?>
<p class="note">Pick an event to see discount total.</p>
<?php endif; ?>

</body>
</html>
