<?php
require_once 'config.php';

$pageTitle = 'Events';
$message = '';
$error = '';

if (isset($_POST['add_event'])) {
    $evCode = (int)$_POST['evCode'];
    $evName = trim($_POST['evName']);
    $evDate = $_POST['evDate'];
    $evVenue = trim($_POST['evVenue']);
    $evRFee = (float)$_POST['evRFee'];

    try {
        $stmt = $pdo->prepare("INSERT INTO Events (evCode, evName, evDate, evVenue, evRFee) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$evCode, $evName, $evDate, $evVenue, $evRFee]);
        $message = 'Event added.';
    } catch (PDOException $e) {
        $error = $e->getMessage();
    }
}

if (isset($_POST['update_event'])) {
    $evCode = (int)$_POST['evCode'];
    $evName = trim($_POST['evName']);
    $evDate = $_POST['evDate'];
    $evVenue = trim($_POST['evVenue']);
    $evRFee = (float)$_POST['evRFee'];

    try {
        $stmt = $pdo->prepare("UPDATE Events SET evName=?, evDate=?, evVenue=?, evRFee=? WHERE evCode=?");
        $stmt->execute([$evName, $evDate, $evVenue, $evRFee, $evCode]);
        $message = 'Event updated.';
    } catch (PDOException $e) {
        $error = $e->getMessage();
    }
}

if (isset($_POST['delete_event'])) {
    $evCode = (int)$_POST['evCode'];
    try {
        $stmt = $pdo->prepare("DELETE FROM Events WHERE evCode=?");
        $stmt->execute([$evCode]);
        $message = 'Event deleted.';
    } catch (PDOException $e) {
        $error = $e->getMessage();
    }
}

$searchResult = null;
$searchCode = '';
if (isset($_GET['search']) && $_GET['search'] !== '') {
    $searchCode = (int)$_GET['search'];
    $stmt = $pdo->prepare("SELECT * FROM Events WHERE evCode=?");
    $stmt->execute([$searchCode]);
    $searchResult = $stmt->fetch();
}

$events = $pdo->query("SELECT * FROM Events ORDER BY evCode")->fetchAll();

require_once 'includes/header.php';
?>
<h1>Events</h1>

<?php if ($message): ?><div class="msg ok"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error): ?><div class="msg error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<h2>Add</h2>
<form method="POST">
    <p><label>Code</label> <input type="number" name="evCode" required></p>
    <p><label>Name</label> <input type="text" name="evName" required></p>
    <p><label>Date</label> <input type="date" name="evDate" required></p>
    <p><label>Venue</label> <input type="text" name="evVenue" required></p>
    <p><label>Fee</label> <input type="number" step="0.01" name="evRFee" required></p>
    <p><button type="submit" name="add_event">Add</button></p>
</form>

<hr>

<h2>Search / Update / Delete</h2>
<form method="GET">
    <p><label>Code</label> <input type="number" name="search" value="<?= htmlspecialchars($searchCode) ?>" required> <button type="submit">Search</button></p>
</form>

<?php if ($searchResult): ?>
<form method="POST">
    <input type="hidden" name="evCode" value="<?= $searchResult['evCode'] ?>">
    <p><label>Code</label> <?= $searchResult['evCode'] ?></p>
    <p><label>Name</label> <input type="text" name="evName" value="<?= htmlspecialchars($searchResult['evName']) ?>" required></p>
    <p><label>Date</label> <input type="date" name="evDate" value="<?= $searchResult['evDate'] ?>" required></p>
    <p><label>Venue</label> <input type="text" name="evVenue" value="<?= htmlspecialchars($searchResult['evVenue']) ?>" required></p>
    <p><label>Fee</label> <input type="number" step="0.01" name="evRFee" value="<?= $searchResult['evRFee'] ?>" required></p>
    <p>
        <button type="submit" name="update_event">Update</button>
        <button type="submit" name="delete_event" onclick="return confirm('Delete?')">Delete</button>
    </p>
</form>
<?php elseif (isset($_GET['search'])): ?>
<p>Not found.</p>
<?php endif; ?>

<hr>

<h2>All Events</h2>
<table>
    <tr>
        <th>Code</th>
        <th>Name</th>
        <th>Date</th>
        <th>Venue</th>
        <th>Fee</th>
    </tr>
    <?php foreach ($events as $event): ?>
    <tr>
        <td><?= $event['evCode'] ?></td>
        <td><?= htmlspecialchars($event['evName']) ?></td>
        <td><?= $event['evDate'] ?></td>
        <td><?= htmlspecialchars($event['evVenue']) ?></td>
        <td><?= number_format($event['evRFee'], 2) ?></td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($events)): ?>
    <tr><td colspan="5">No events.</td></tr>
    <?php endif; ?>
</table>

</body>
</html>
