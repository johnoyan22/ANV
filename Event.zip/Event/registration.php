<?php
require_once 'config.php';

$pageTitle = 'Registration';
$message = '';
$error = '';

$participantsList = $pdo->query("
    SELECT p.partID, p.partFName, p.partLName, p.partDRate, p.evCode, e.evName, e.evRFee
    FROM Participants p
    JOIN Events e ON p.evCode = e.evCode
    ORDER BY p.partID
")->fetchAll();

if (isset($_POST['register'])) {
    $partID = (int)$_POST['partID'];
    $regDate = $_POST['regDate'];
    $regPMode = $_POST['regPMode'];

    $stmt = $pdo->prepare("
        SELECT p.partDRate, e.evRFee
        FROM Participants p
        JOIN Events e ON p.evCode = e.evCode
        WHERE p.partID = ?
    ");
    $stmt->execute([$partID]);
    $data = $stmt->fetch();

    if ($data) {
        $regPaid = $data['evRFee'] - $data['partDRate'];
        try {
            $stmt = $pdo->prepare("INSERT INTO Registration (partID, regDate, regPaid, regPMode) VALUES (?, ?, ?, ?)");
            $stmt->execute([$partID, $regDate, $regPaid, $regPMode]);
            $message = 'Registered. Fee paid: ' . number_format($regPaid, 2);
        } catch (PDOException $e) {
            $error = $e->getMessage();
        }
    } else {
        $error = 'Participant not found.';
    }
}

$registrations = $pdo->query("
    SELECT r.regCode, r.regDate, r.regPaid, r.regPMode,
           p.partFName, p.partLName,
           e.evName
    FROM Registration r
    JOIN Participants p ON r.partID = p.partID
    JOIN Events e ON p.evCode = e.evCode
    ORDER BY r.regDate DESC, r.regCode DESC
")->fetchAll();

require_once 'includes/header.php';
?>
<h1>Registration</h1>

<?php if ($message): ?><div class="msg ok"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error): ?><div class="msg error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<h2>Register</h2>
<form method="POST">
    <p><label>Participant</label>
        <select name="partID" id="partID" required onchange="showFee()">
            <option value="">-- select --</option>
            <?php foreach ($participantsList as $p): ?>
            <option value="<?= $p['partID'] ?>"
                data-fee="<?= $p['evRFee'] ?>"
                data-discount="<?= $p['partDRate'] ?>">
                <?= $p['partID'] ?> - <?= htmlspecialchars($p['partFName'] . ' ' . $p['partLName']) ?> (<?= htmlspecialchars($p['evName']) ?>)
            </option>
            <?php endforeach; ?>
        </select>
    </p>
    <p><label>Date</label> <input type="date" name="regDate" value="<?= date('Y-m-d') ?>" required></p>
    <p><label>Payment</label>
        <select name="regPMode" required>
            <option value="Cash">Cash</option>
            <option value="Card">Card</option>
        </select>
    </p>
    <p class="note" id="feePreview" style="display:none;">
        Fee: <span id="evFee">0.00</span> − Discount: <span id="discount">0.00</span> = <strong><span id="amountDue">0.00</span></strong>
    </p>
    <p><button type="submit" name="register">Register</button></p>
</form>

<hr>

<h2>Transactions</h2>
<table>
    <tr>
        <th>Code</th>
        <th>Event</th>
        <th>Participant</th>
        <th>Date</th>
        <th>Paid</th>
        <th>Payment</th>
    </tr>
    <?php foreach ($registrations as $r): ?>
    <tr>
        <td><?= $r['regCode'] ?></td>
        <td><?= htmlspecialchars($r['evName']) ?></td>
        <td><?= htmlspecialchars($r['partFName'] . ' ' . $r['partLName']) ?></td>
        <td><?= $r['regDate'] ?></td>
        <td><?= number_format($r['regPaid'], 2) ?></td>
        <td><?= htmlspecialchars($r['regPMode']) ?></td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($registrations)): ?>
    <tr><td colspan="6">No records.</td></tr>
    <?php endif; ?>
</table>

<script>
function showFee() {
    var select = document.getElementById('partID');
    var option = select.options[select.selectedIndex];
    var preview = document.getElementById('feePreview');

    if (!option.value) {
        preview.style.display = 'none';
        return;
    }

    var fee = parseFloat(option.dataset.fee);
    var discount = parseFloat(option.dataset.discount);
    document.getElementById('evFee').textContent = fee.toFixed(2);
    document.getElementById('discount').textContent = discount.toFixed(2);
    document.getElementById('amountDue').textContent = (fee - discount).toFixed(2);
    preview.style.display = 'block';
}
</script>

</body>
</html>
