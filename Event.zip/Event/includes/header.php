<?php
$pageTitle = $pageTitle ?? 'Events Registration';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <a href="index.php">Home</a>
        <a href="events.php">Events</a>
        <a href="participants.php">Participants</a>
        <a href="registration.php">Registration</a>
        <a href="monitoring.php">Monitoring</a>
    </nav>
