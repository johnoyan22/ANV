CREATE DATABASE IF NOT EXISTS events_registration;
USE events_registration;

CREATE TABLE Events (
    evCode INT PRIMARY KEY,
    evName TEXT NOT NULL,
    evDate DATE NOT NULL,
    evVenue TEXT NOT NULL,
    evRFee DECIMAL(10,2) NOT NULL
);

CREATE TABLE Participants (
    partID INT PRIMARY KEY,
    evCode INT NOT NULL,
    partFName TEXT NOT NULL,
    partLName TEXT NOT NULL,
    partDRate DECIMAL(10,2) NOT NULL DEFAULT 0,
    FOREIGN KEY (evCode) REFERENCES Events(evCode)
);

CREATE TABLE Registration (
    regCode INT PRIMARY KEY AUTO_INCREMENT,
    partID INT NOT NULL,
    regDate DATE NOT NULL,
    regPaid DECIMAL(10,2) NOT NULL,
    regPMode TEXT NOT NULL,
    FOREIGN KEY (partID) REFERENCES Participants(partID)
);

INSERT INTO Events (evCode, evName, evDate, evVenue, evRFee) VALUES
(1, 'Tech Summit 2024', '2024-11-15', 'UC Main Auditorium', 500.00),
(2, 'Sports Fest', '2024-12-01', 'UC Gymnasium', 300.00);

INSERT INTO Participants (partID, evCode, partFName, partLName, partDRate) VALUES
(1001, 1, 'Juan', 'Dela Cruz', 50.00),
(1002, 1, 'Maria', 'Santos', 0.00),
(1003, 2, 'Pedro', 'Reyes', 30.00);
