<?php
$pageTitle = 'Events Registration System';
require_once 'includes/header.php';
?>
<h1>Events Registration System</h1>
</body>
</html>
